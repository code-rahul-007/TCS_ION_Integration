import React, { useState ,useEffect} from 'react';
import '../css/alert.scss';
import { useStateValue } from '../state';
import { resetState } from "../actions/homeAction";
import {videoSrcbg, videoSrcHn,  videoSrc, codeExplanationBg, codeExplanationHn, codeExplanation, }from "../constants/inventoryConstants";
import {
  downloadInterestInventoryDocument,deleteInterestInventoryDocument
} from "./../actions/documentActions";
import {
  updateInterestInventoryCode,
} from "./../actions/interestInventoryActions";
import Text from "@material-ui/core/FormHelperText";
import { useTranslation } from 'react-i18next';
import {hideConfirm, showConfirm, enableReplay, disableReplay} from "../actions/confirmAction";
import ConfirmationDialog from './ConfirmationDialog';


const Alert = () => {
const [{ jwtToken }, dispatch] = useStateValue();
const [{ studentDetails }] = useStateValue();
const [{ inventoryDetails }] = useStateValue();
const [{ documentDetails }] = useStateValue();
const [{ courseDetails }] = useStateValue();
const [url, setUrl] = useState("");
const { t, i18n } = useTranslation();
const [{ dialog }] = useStateValue();
const lng = i18n.language || window.localStorage.getItem("lng");


// Added language condition to accomodate the language specif videos
useEffect(() => {
  if(lng === "bg"){
  const src = (videoSrcbg.filter((video) => video.letter === (inventoryDetails?.inventory?.finalScore[0])).map(filteredVideo => filteredVideo.source))[0];
  setUrl('https://www.youtube.com/embed/'+src+'?playlist='+src+'&loop=1');
  }

  else if(lng === "hn"){
    const src = (videoSrcHn.filter((video) => video.letter === (inventoryDetails?.inventory?.finalScore[0])).map(filteredVideo => filteredVideo.source))[0];
    setUrl('https://www.youtube.com/embed/'+src+'?playlist='+src+'&loop=1');
    }
  
  else{
    const src = (videoSrc.filter((video) => video.letter === (inventoryDetails?.inventory?.finalScore[0])).map(filteredVideo => filteredVideo.source))[0];
    setUrl('https://www.youtube.com/embed/'+src+'?playlist='+src+'&loop=1');
    }
},[inventoryDetails?.inventory?.finalScore]); 

const getCodeText = (hollandCode) => {
 // const lng = i18n.language || window.localStorage.getItem("lng");
  if(lng === "bg"){
    const letters = hollandCode.split('');
    const codeText = [];
    letters.map(letter => (
      codeText.push(codeExplanationBg.filter((l) => l.letter === letter))
    ));
    return codeText;
  }

  else if(lng === "hn"){
    const letters = hollandCode.split('');
    const codeText = [];
    letters.map(letter => (
      codeText.push(codeExplanationHn.filter((l) => l.letter === letter))
    ));
    return codeText;
  }

  else {
    const letters = hollandCode.split('');
    const codeText = [];
    letters.map(letter => (
      codeText.push(codeExplanation.filter((l) => l.letter === letter))
    ));
    return codeText;
  }
};


const downloadIntInvDocument = () => {
  if(documentDetails?.documentPath === undefined){
    downloadInterestInventoryDocument(dispatch, documentDetails?.basicDocId, jwtToken);    
  } else {
    const url = process.env.REACT_APP_API_ENDPOINT + "Downloads/" + documentDetails?.documentPath + "";
    window.open(url, "_blank"); 
  }
};

const enableCounselling = () => {
  const connectCounsellor = "YES";
  updateInterestInventoryCode(dispatch, studentDetails?.student?.engagementId,jwtToken,inventoryDetails?.inventory?.finalScore,inventoryDetails?.result, inventoryDetails?.inventory?.id,inventoryDetails?.inventory?.hollandCodeReverificationCode,"YES")
        
};


const handleReplayGame = () => {
  showConfirm(dispatch);
}

const onReplayDismiss = () => {
  hideConfirm(dispatch);
}
const onReplayConfirm = () => {
  hideConfirm(dispatch);
  enableReplay(dispatch);
/* reset finalscore, chatbot score and connectCounsellor option on the student id */
/* also update generated document status to inactive */
  updateInterestInventoryCode(dispatch, studentDetails?.student?.engagementId,jwtToken,"","", inventoryDetails?.inventory?.id,"","NO");
  deleteInterestInventoryDocument(dispatch, documentDetails?.basicDocId, jwtToken);
}

return (
  
    <div class="alert_container-padding">   
    
        <div calssName ="alert_center_aligned">
          <div class = "alert_bold-heading center_aligned"> {t('dear')} {studentDetails?.student?.firstName} ! </div> 
          <div class ="bold-black-heading center_aligned_flexstart" > {t('alertPageResultMsg')} <span class="bold-blue-heading"> {inventoryDetails?.inventory?.finalScore} </span></div>
          <div class = "alert_text-reduced row_center">  
            <table>
                {getCodeText(inventoryDetails?.inventory?.finalScore).map((item) => (
                <tr className= "inv-tr">
                  <td key = {item[0].letter}><Text class="alert-results-text-reduced"> {item[0].letter} </Text></td> 
                  <td><Text class="alert-results-text-reduced"> {":"}</Text></td>
                  <td key = {item[0].text}> <Text class="alert-results-text-reduced">{item[0].text}</Text></td>
                </tr>
              ))}
            </table> 
          </div>  
        </div>
      

        {courseDetails?.courseListCompleted && documentDetails?.basicDocId > 0 ? (
        <div> 
          {courseDetails?.courses?.length === 0 && courseDetails?.trades?.length === 0 && (
            <div>
            <div class="bold-heading center_aligned"> {" "}{t('noCoursesText')}{" "}</div>
            <div class="bold-heading center_aligned"> <a target= "_blank" href="https://www.tatastrive.com/Courses.html"> {t('explore')} </a></div>
            </div>

          )}
          {courseDetails?.courses?.length > 0 && courseDetails?.trades.length > 0 ? (
            <div class="row_center">
              <div class="bold-black-heading">{" "}{t('resultText1')} <span class="bold-heading"> {inventoryDetails?.inventory?.finalScore} </span> {t('resultText2')}{" "}</div>
              <div class="center_aligned">
                <table className="alert_table">
                  <tr class="alert_text-reduced">
                    <td style={{border: "1px solid grey"}}> {t('JobRole')} </td>
                    <td style={{border: "1px solid grey"}}>{t('sector')}</td>
                 </tr>
                  {courseDetails?.trades.map((item) => (
                    <tr key={item} class="alert_text-reduced" >
                      
                      <td style={{border: "1px solid grey"}}>
                        <table className="alert_table">
                          {(courseDetails?.objectsFromHollandCode.filter((i) => i.trade === item)).map(i => (
                          <tr><td class="alert_text-reduced_left"> {i.course}</td></tr> ))} 
                        </table>
                      </td>
                      <td style={{border: "1px solid grey"}}><a className="alert_link-style" target= "_blank" href= {(courseDetails?.objectsFromHollandCode.filter((h) => h.trade === item))[0]?.coursePath}>{item}</a> </td>
                    
                      </tr> ))
                  }  
              </table> 
              </div>
            </div>
          ): (<div></div>)}
        </div>
        ) : (<div></div>)}

        <div className="alert_text-reduced_left row_center"> {t('watchCareerVideo')} </div>
          
          <div className="row_center">
            <iframe
              src= {url}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title="YouTube video player"
              width="90%"
              height="200px"
            /> 
          </div> 
        
        <div>

      <div>&nbsp;</div>
      {(inventoryDetails?.inventory?.hollandCodeReverificationCode < 5) && ( 
        <div class="alert_text-reduced center_aligned" >{t('recommendCounsellor')}</div>
      )} 

      { documentDetails?.basicDocId > 0 && (
        <div className="alert_center_aligned_row"> 
          <div> 
          <button type="submit" className="alert_submit-download" onClick={downloadIntInvDocument}>{t('DownloadReport')}</button>
          </div>
          <div>
          {(inventoryDetails?.inventory?.connectCounselor === "YES") ? (
          
          <button type="submit" class="alert_submit-download-grey">{t('reachToCounsellorButton')}</button> ) : (
          <button type="submit" class="alert_submit-download" onClick={enableCounselling} > {t('reachToCounsellorButton')} </button>
          )}
          </div> 
          <div> 
        <button type="submit" className="result-submit-download" onClick={handleReplayGame}>{t('ReplayGame')}</button>
        </div>

        </div>
      )} 
      
      {(inventoryDetails?.inventory?.connectCounselor === "YES" ) && (
      <div class="highlight-text center_aligned" > {t('thankYouForCounsellorRequest')}</div>
      )}
      </div>

      <div>
        {dialog.confirm && <ConfirmationDialog open = {true} title = {t('confirmReplayOption')} onConfirm = {onReplayConfirm} onDismiss = {onReplayDismiss}></ConfirmationDialog>}
      </div>

      <div class= "alert_text-reduced center_aligned_flexstart" >{t('contactUs1')} <span className = "bold-black-text"> {t('csNumber')} </span> {t('contactUs2')} {t('contactUs3')}</div>   
    
    </div>

  
    );
  }

export default Alert;
 