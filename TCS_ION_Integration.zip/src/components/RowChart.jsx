import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, ReferenceLine,
} from 'recharts';
import '../css/rowChart.scss';


class RowChart extends React.Component {

    constructor(props)
    {
        super(props);
        let datastring  = props.data;
        if(datastring !== null && datastring !== undefined){
        datastring = datastring.replace(/\~/g, '"'); 
      }
        this.chart = {data : JSON.parse(datastring)};
      
    }

  render() {
    return (
      // <BarChart
      //  // width={800}
      // width={300}
      // height={200}
      //  // height={300}
      //   data={this.chart.data}
      //   stackOffset="sign"
      //  margin={{ top: 5, right: 30, left: 20, bottom: 5,}}
      // >
      //   <CartesianGrid strokeDasharray="3 3" />
      //   <XAxis dataKey="category" />
      //   <YAxis />
      //   <Tooltip />
      //   <Legend/>
      //   <ReferenceLine y={0} stroke="#000" />
      //   <Bar dataKey="like" fill="#8884d8" stackId="stack" />
      //   <Bar dataKey="unlike" fill="#82ca9d" stackId="stack" />
      // </BarChart>
      <div className="chart_container">  
    
    <BarChart
        width={230}
        height={170}
        data={this.chart.data}
        stackOffset="sign"
        margin={{
        //  top: 5, 
          // right: 30, 
           left: -20,
          // bottom: 5,
        }}
      >
        {/* <CartesianGrid strokeDasharray="3 3" /> */}
        <XAxis style={{
          fontSize: '1.7vmin',
          fontFamily: 'Myriad Pro',
          color: 'black',
          }}
     dataKey="letter" tickMargin={0} tickLine={false} axisLine={false}/> 
        <YAxis style={{
          fontSize: '1.7vmin',
          fontFamily: 'Myriad Pro',
          }} />
        <ReferenceLine y={0} stroke="#000000" />
        <Bar dataKey="like" fill="#8884d8" stackId="stack" />
        <Bar dataKey="unlike" fill="#82ca9d" stackId="stack" />
      </BarChart>
      
      </div>
    );
  }
}



export default RowChart; 