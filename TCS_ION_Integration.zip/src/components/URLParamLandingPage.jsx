import React from "react";
import {
    BrowserRouter as Router,
    useLocation,
} from "react-router-dom";
import MainForURLParamEngID from './MainForURLParamEngID';

/*this will be the landing page incase the URL is found with Eng ID embedded*/

/*For Routing the page to different directions incase of any other URL 
add another Route and function if required for segregating the dataset*/
export default function URLParamLandingPage() {
    return (
        <Router>
            <LandingQueryParams />
        </Router>
    );
}

/*This will be for segregating the URL parameters this 
will search based on the search string provided */
function useQuery() {
    const { search } = useLocation();
    return React.useMemo(() => new URLSearchParams(search), [search]);
}

/*This will be the main page wherein we are getting the data and calling the component*/
function LandingQueryParams() {
    let query = useQuery();
    return (
        <div>
            <MainForURLParamEngID props={query.get("Id")}/>
        </div>
    );
}

