import React, { useState } from 'react';
import "react-phone-number-input/style.css";
import Input from "react-phone-number-input/input";
import '../css/mobileNumber.scss';
import './../assets/css/font-awesome.min.css'
import { validateDOB, validateMobileNumber, validateMobileNumberErrors } from '../utils/validation';
import { useTranslation } from 'react-i18next';
import Select from "react-select";

const MobileNumber = (props) => {
    const {onClick, language} = props;
    const [mobileNumber, setMobileNumber] = useState();
    const [errors, setErrors] = useState({})
    const [dob, setDob] = useState();
    const { t, i18n } = useTranslation();

    const getUserData = () => ({
        mobileNumber,
        dob,
        language,
        verified:false
      });

    const setGetOtp = (event) => {
        event.preventDefault();
        const userData = {...getUserData()}
        if(!validateMobileNumberErrors(errors)) onClick(event, userData);
    }

    const onChangeDob = (event) => {
        if(event?.target?.value){
            const errors = validateDOB(event?.target?.value, language);
            setErrors(errors);

            setDob(event?.target?.value);
        }
    }

    const onChangeMobile = (event) => {
        if(event){
            const errors = validateMobileNumber(event.substring(3), language);
            setErrors(errors);
            setMobileNumber(event);
        }else {
            setMobileNumber("")
            setErrors(validateMobileNumber("", language));
        }
    }
    
    return (
    <div>   
        <div className= "mobileNumber-form"> 
            <form  onSubmit={setGetOtp}>

                <div className= "welcometext-input"> 
                    {t('welcomeText')}
                </div>
                <div className = "mobileNumber-header">
                    <div className="mobileNumber-input">    
                        <span className="fa fa-mobile" aria-hidden="true"/> 
                        <Input 
                        defaultCountry="IN"
                        maxLength= "12"
                        value={mobileNumber}
                        placeholder = {t('mobileNumber')}                
                        onChange={e => onChangeMobile(e)} 
                        required />
                    </div>
                    {errors?.mobileNumber ? <div class = "mobileNumber-input-error">{errors.mobileNumber}</div> : null }  
                    <div className="mobileNumber-input">
                        <input type="date"   
                        onChange={e => onChangeDob(e)}
                        value={dob} required
                        placeholder = {t('dob')}
                        />
                    </div>      
                    {errors?.dob ? <div class = "mobileNumber-input-error">{errors.dob}</div> : null }    
                    <div id="recaptcha"></div>
                    {validateMobileNumberErrors(errors) ? <button type="submit" className="mobileNumber-submit-grey">{t('otp')}</button> : <button type="submit" class="mobileNumber-submit">{t('otp')}</button> }   
                </div>
            </form>
        </div>
    </div> 
    );
 } 

export default MobileNumber;