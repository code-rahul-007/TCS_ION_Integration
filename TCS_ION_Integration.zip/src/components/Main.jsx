import React, { useState, useEffect } from "react";
import GameTransition from "./GameTransition";
import SigninForm from "./SigninForm";
import Alert from "./Alert";
import PersonForm from "./PersonForm";
import { useStateValue } from "../state";
import { getJwtToken } from "../actions/jwtTokenActions";
import { getEngagementId } from "../actions/studentActions";
import { viewInventoryData } from "../actions/interestInventoryActions";
import { fetchCoursesByHollandCode } from "./../actions/courseActions";
import { getInventoryDocumentDetails } from "./../actions/documentActions";
import Header from './Header';
import Footer from './Footer';
import '../css/main.scss';

const Main = () => {
  
  const [finalResultAvilable, setfinalResultAvilable] = useState();
  const [userData, setuserData] = useState({});
  const [{ jwtToken }, dispatch] = useStateValue();
  const [{ studentDetails }] = useStateValue();
  const [{ inventoryDetails }] = useStateValue();
  const [{ documentDetails }] = useStateValue();
  const [{ dialog }] = useStateValue();

  useEffect(() => {
    if (!jwtToken?.token){
      getJwtToken(dispatch);
    }
  }, []);

  // Get Student details based on mobile number and dob
  useEffect(() => {
    if (userData?.mobileNumber) {
      getEngagementId(dispatch, jwtToken, userData);
    }
  }, [userData?.mobileNumber]);

  // Get Inventory data - only once
  useEffect(() => {
    if (studentDetails?.student &&!finalResultAvilable) {
      viewInventoryData(dispatch, jwtToken, studentDetails?.student?.engagementId );
    }
  }, [studentDetails?.student]);

  // fetch courses based on hollandCode and verify for document details against the engagementId 
  useEffect(() => {
    if(inventoryDetails?.inventory?.finalScore && studentDetails.student?.engagementId){
      fetchCoursesByHollandCode(dispatch, inventoryDetails?.inventory?.finalScore, jwtToken);
      getInventoryDocumentDetails(dispatch, studentDetails.student?.engagementId, jwtToken);
    }
  }, [inventoryDetails?.inventory?.hollandCodeReverificationCode]);
  

  useEffect(() => {
    if(documentDetails?.documentPath !== undefined && documentDetails?.documentPath?.length>0){
      setfinalResultAvilable(true);
    }
  }, [documentDetails?.basicDocId]);

  
// verify OTP for the mobile number login
  const verifyMobileNumber = async (userData) => {
    try {
      userData = {
        ...userData,
        mobileNumber: userData.mobileNumber.substring(3),
      };
      setuserData(userData);
    } catch (error) {
      alert("Invalid code");
    }
  };

  return ( 
    <div class="main_container"> 
    <table class="table_border_blue" width="100%">
      {/* header row */}
      <tr>
        <td>
      <div>
        <Header/>
      </div>
      </td>
      </tr>
      {/* central component row - background image */}
      <tr >
        <td >
      <div>
        {/*New User - Show Sign_in Screen Screen*/}
        {!userData.verified && (
          <div class="main-body-image">
            <SigninForm verifyMobileNumber={verifyMobileNumber} />
          </div>
        )}
        
        {/*Returning User - Show Sign_in Screen Screen*/}
        {userData.mobileNumber !== undefined && userData.verified && (
          
          
          <div>

            {/*Nothing completed, hence show profile screen post sign-in - No engagement ID*/}
            <div> 
              {!studentDetails?.student?.engagementId && !studentDetails?.loading  && (
                <PersonForm userData={userData} student= {studentDetails?.student}/> 
              )}
            </div>


            {/*Only Profile Completed, Game/bot not Played , No holland code*/}
            <div>
              {(studentDetails?.student?.engagementId && (inventoryDetails?.inventory?.finalScore === undefined || inventoryDetails?.inventory?.finalScore?.length === 0  || inventoryDetails?.inventory?.hollandCodeReverificationCode === undefined || !finalResultAvilable || dialog.enableReplay) )&& (    
                <GameTransition />
              )}  
            </div>
            

            {/* All are completed - display results */}
            <div>  
              {finalResultAvilable && !dialog.enableReplay && (
              <Alert/>
              )}
            </div>
      
          </div>   
        )}
      </div>
      </td>
      </tr>
      {/* footer row */}
      <tr >
        <td >
      <div>
        <Footer />
      </div>
      </td>
      </tr>
      </table>
    </div>
  );
};

export default Main;
