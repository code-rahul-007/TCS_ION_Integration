import React, { useState  , useEffect } from 'react';
import firebase from "../services/firebase";
import '../css/mobileNumber.scss';
import { validateOtp, validateOtpErrors } from '../utils/validation';
import { useTranslation } from 'react-i18next';

const Otp = (props) => {
    const { onSubmitCode , userData } = props;
    const [ code, setCode ] = useState('');
    const [errors, setErrors] = useState({});
    const [confirm, setConfirm] = useState(null);
    const [enableResend, setEnableResend] = useState(false);
    const { t, i18n } = useTranslation();
  
    useEffect(() => {
      const timer = setTimeout(() => {
      }, 20000);
      setEnableResend(true);
      return () => {
        clearTimeout(timer); 
        setEnableResend(false); 
      }
    });
    
    const setNewOtp = (event) => {
        event.preventDefault();
        if(!validateOtpErrors(errors)) onSubmitCode(code);
    }
    const onChangeOtp = (event) => {
        if(event?.target?.value || event?.target?.value?.length === 0){
          const lng = window.localStorage.getItem("lng");
            const errors = validateOtp(event?.target?.value, lng);
            setErrors(errors);
            setCode(event?.target?.value);
        }
      }

    const handleResendOTP = async () => {
        window.recaptcha = new firebase.auth.RecaptchaVerifier("recaptcha-resend",{
          'size': 'invisible'});
        // Commented to Disable the OTP valication and passing empty object in setConfirm()
        // const confirmation = await firebase.auth().signInWithPhoneNumber(userData?.mobileNumber, window.recaptcha);
        setConfirm({});
          // confirmation);
      }

    return (
      <div className= "mobileNumber-form"> 
        <form onSubmit= {setNewOtp} >
        <div className= "welcometext-input">
           {t('welcomeText')}
        </div>
        
        <div className = "mobileNumber-header">
          <div className="mobileNumber-input"> 
            <input
              placeholder={t('enterOTP')}
              value={code}
              maxLength="6"
              name="otp"
              onChange={e => onChangeOtp(e)}
            />
          </div>
          {
              errors?.otp && <div class = "mobileNumber-input-error">{errors.otp}</div>             
          }  
          {
            validateOtpErrors(errors) ? <button type="submit" className="mobileNumber-submit-grey">{t('validateOTP')}</button> : <button type="submit" class="mobileNumber-submit">{t('validateOTP')}</button>
          }
          <div className="mobileNumber-resend-OTP"></div>
          {
            validateOtpErrors(errors)  ? <button type="submit" className="mobileNumber-submit" onClick={handleResendOTP}>{t('resendOTP')}</button> : <button type="button" className="mobileNumber-submit-grey" 
          >{t('resendOTP')}</button>
          }
          
          <div id="recaptcha-resend"></div>
          <div className="mobileNumber-resend-OTP"></div>
          
          </div>
        </form>
      
      </div>

    );
}

export default Otp;
