import React from "react";
import '../css/footer.scss';
import wbLogo from '../assets/images/TataSTRIVE.png';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t, i18n } = useTranslation();

  return(
  <div className="footer">
    <div className= "text">{t('partnership')} &nbsp;<img className= "img"src={wbLogo}alt="logo"/>&nbsp; <text className="small-text" >V 1.1</text> </div>
  </div>
  );
}

export default Footer;