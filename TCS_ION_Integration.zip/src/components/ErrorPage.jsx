import React from "react";
import "../css/user-not-found.scss";

const UserNotFound = () => {
  return (
    <>
      <main>
        <div class="container">
          {/* <div class="row"> */}
          <div class=" text-align-center"></div>
          <div class=" text-align-center">
            <center>
              <h1>404</h1>
              <h2>Not a Valid User!!! Please check your ID</h2>
              <p>
                The user you are looking for does not exist. Click the button
                below to go back to the homepage.
              </p>
              <button class="btn green">
                <a href="/" style={{ textDecoration: "none"}}>
                  HOME
                </a>
              </button>
            </center>
          </div>
          {/* </div> */}
        </div>
      </main>
    </>
  );
};

export default UserNotFound