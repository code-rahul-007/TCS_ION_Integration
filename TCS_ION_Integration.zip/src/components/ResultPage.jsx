import React, { useEffect, useState } from 'react';
import '../css/resultPage.scss';
import { useStateValue } from '../state';
import {
  downloadInterestInventoryDocument,
  deleteInterestInventoryDocument,
} from "./../actions/documentActions";
import {
  updateInterestInventoryCode,
} from "./../actions/interestInventoryActions";
import { saveFeedback } from "./../actions/feedbackActions";
import { useTranslation } from 'react-i18next';
import Button from "@material-ui/core/Button";
import Text from "@material-ui/core/FormHelperText";
import {hideConfirm, showConfirm, enableReplay, disableReplay} from "../actions/confirmAction";
import ConfirmationDialog from './ConfirmationDialog';
import GameTransition from './GameTransition';

const ResultPage = () => {
  const [{ jwtToken }, dispatch] = useStateValue();
  const [{ studentDetails }] = useStateValue();
  const [{ inventoryDetails }] = useStateValue();
  const [{ documentDetails }] = useStateValue();
  const [{ courseDetails }] = useStateValue();
  const [{ feedbackDetails }] = useStateValue();
  const { t, i18n } = useTranslation();
  const [replayGame, setReplayGame] = useState(false);
  const [{ dialog }] = useStateValue();
  
  useEffect(() => {
    downloadInterestInventoryDocument(dispatch, documentDetails?.basicDocId, jwtToken); 
  }, [documentDetails?.documentPath === null]);

  const downloadIntInvDocument = () => {
    if(documentDetails?.documentPath === undefined || documentDetails?.documentPath === null){
         
    } else {
      const url = process.env.REACT_APP_API_ENDPOINT + "Downloads/" + documentDetails?.documentPath + "";
      window.open(url, "_blank"); 
    } 
  };

  const enableCounselling = () => {
    updateInterestInventoryCode(dispatch, studentDetails?.student?.engagementId,jwtToken,inventoryDetails?.inventory?.finalScore,inventoryDetails?.result, inventoryDetails?.inventory?.id,inventoryDetails?.inventory?.hollandCodeReverificationCode,"YES")
  
  };

  const updateFeedback = (event,feedback) => {
    event.preventDefault();
    saveFeedback(dispatch, studentDetails?.student?.engagementId, jwtToken, feedback);
  }

  const handleReplayGame = () => {
    showConfirm(dispatch);
  }

  const onReplayDismiss = () => {
    hideConfirm(dispatch);
  }
  const onReplayConfirm = () => {
    hideConfirm(dispatch);
    enableReplay(dispatch);
/* reset finalscore, chatbot score and connectCounsellor option on the student id */
/* also update generated document status to inactive */
    updateInterestInventoryCode(dispatch, studentDetails?.student?.engagementId,jwtToken,"","", inventoryDetails?.inventory?.id,"","NO");
    deleteInterestInventoryDocument(dispatch, documentDetails?.basicDocId, jwtToken);
  }
  
  return (
    <div>   
  
      {courseDetails?.courseListCompleted ? (
        <div> 
          {courseDetails?.courses?.length === 0 && courseDetails?.trades?.length === 0 && (
            <div>
            <div class="bold-heading center_aligned"> {" "}{t('noCoursesText')}{" "}</div>
            <div class="bold-heading center_aligned"> <a target= "_blank" href="https://www.tatastrive.com/Courses.html"> {t('explore')}</a></div>
            </div>

          )}
          {courseDetails?.courses?.length > 0 && courseDetails?.trades.length > 0 && (
            <div class="row_center">
              <div class="bold-black-heading_result">{" "}{t('resultText1')} <span class="bold-blue-heading"> {inventoryDetails?.inventory?.finalScore} </span> {t('resultText2')}{" "}</div>
              <div>&nbsp;</div>
              <div class="center_aligned">
                <table className="result_table">
                  <tr class="text-reduced" >
                    <td style={{border: "1px solid grey"}}>{t('JobRole')} </td>
                    <td style={{border: "1px solid grey"}}>{t('sector')}</td>
                 </tr>
                  {courseDetails?.trades.map((item) => (
                    <tr key={item} class="text-reduced-result" >
                      
                      <td style={{border: "1px solid grey"}}>
                        <table className="result_table">
                          {(courseDetails?.objectsFromHollandCode.filter((i) => i.trade === item)).map(i => (
                          <tr><td class="text-reduced_left"> {i.course}</td></tr> ))} 
                        </table>
                      </td>
                      <td style={{border: "1px solid grey"}}><a className="link-style" target= "_blank" href= {(courseDetails?.objectsFromHollandCode.filter((h) => h.trade === item))[0]?.coursePath}>{item}</a> </td>
                    
                      </tr> ))
                  }  
              </table> 
              </div>

            </div>
          )}
        </div>
      ) : (<div></div>)}

      <div>&nbsp;</div>

      {(inventoryDetails?.inventory?.hollandCodeReverificationCode < 5) && ( 
      <div class="alert_text-reduced center_aligned" >{t('recommendCounsellor')}</div>
      )}

      {(inventoryDetails?.inventorySaved && documentDetails?.basicDocId > 0 && documentDetails?.documentSaved === true) ? (
        <div className="center_aligned_row"> 
        <div> 
        <button type="submit" className="result-submit-download" onClick={downloadIntInvDocument}>{t('DownloadReport')}</button>
        </div>
        <div>
        {(inventoryDetails?.inventory?.connectCounselor === "YES" ) ? ( 
        <button type="submit" class="result-submit-download-grey">{t('reachToCounsellorButton')}</button> ) : (
        <button type="submit" class="result-submit-download" onClick={enableCounselling} > {t('reachToCounsellorButton')} </button>
        )}
        </div>
        <div> 
        <button type="submit" className="result-submit-download" onClick={handleReplayGame}>{t('ReplayGame')}</button>
        </div>
      </div>
      ):(<div class="alert_text-reduced center_aligned"> {t('internetError')} </div>)} 
      
      {/* update user on enabling counsellor request*/}
      {(inventoryDetails?.inventory?.connectCounselor === "YES" ) && ( 
      <div class="highlight-text center_aligned" >{t('thankYouForCounsellorRequest')}</div>
      )}
      <div>&nbsp;</div>
      <div className="alert_text-reduced center-aligned-flexstart-result">
      <div> {t('contactUs1')} <span className = "bold-black-text">{t('csNumber')}</span> {t('contactUs2')} {t('contactUs3')}</div>
      </div>
      <div>&nbsp;</div>
      
      {/* capture feedback from the user */}
      {!feedbackDetails?.feedback && (
      <div>
      <div class= "alert_text-reduced center_aligned_row_text" > {t('askFeedback')}</div>    
      <div class= "alert_text-reduced center_aligned_row_text" >
      <div className="image_style" >
                <Button class="nonebtn" value="thumbsUp" onClick={(e) => updateFeedback(e,"yes")}>
                  <img class="responseImage" src={ process.env.PUBLIC_URL + "/icons/" + "thumbsUp.png"}/>
                  <Text class="centertext">{t('like')}</Text>
                </Button>
      </div>
      <div className="image_style">
                <Button class="nonebtn" value="thumbsDown" onClick={(e) => updateFeedback(e,"no")}>
                  <img class="responseImage" src={ process.env.PUBLIC_URL + "/icons/" + "thumbsDown.png"}/>
                  <Text class="centertext">{t('dislike')}</Text>
                </Button>
      </div>
      </div> 
      </div>
      )}

      {(feedbackDetails?.feedback?.Id > 0) && (
        <div class="feedback-text center_aligned" >{t('thankYouForFeedback')}</div>
      )}

      <div>
        {dialog.confirm && <ConfirmationDialog open = {true} title = {t('confirmReplayOption')} onConfirm = {onReplayConfirm} onDismiss = {onReplayDismiss}></ConfirmationDialog>}
      </div>
   
  </div>
  );
}

export default ResultPage;
 