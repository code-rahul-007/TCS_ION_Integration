import React, { useState, useEffect, useRef } from "react";
import Select from "react-select";
import "../css/basicDetailsForm.scss";
import "./../assets/css/font-awesome.min.css";
import { createStudent } from "../actions/studentActions";
import { useStateValue } from "../state";
import {
  validatePincode,
  validateTextInput,
  validateSelectInput,
  validatePersonFormErrors,
  validateMailId,
  validateDistrict,
  validateVillage,
} from "../utils/validation";
import { getDistrict } from "../actions/cityVillageActions";
import { useTranslation } from 'react-i18next';


const PersonForm = (props) => {
  const { userData, student } = props;
  const [firstName, setFirstName] = useState(student?.firstName);
  const [dob] = useState(userData?.dob);
  const [mobileNumber] = useState(userData?.mobileNumber);
  const [language] = useState(userData?.language);
  const [lastName, setLastName] = useState("");
  const [{ jwtToken }, dispatch] = useStateValue();
  const [highestQualification, setQualification] = useState("");
  const [pincode, setPincode] = useState("");
  const [gender, setGender] = useState("");
  const [errors, setErrors] = useState({});
  const [village, setVillage] = useState("");
  const [address, setAddress] = useState("");
  const [mailId, setMailId] = useState("");
  const [district, setDistrict] = useState("");
  const [{ cityVillageDetails }] = useStateValue();
  const { t, i18n } = useTranslation();
  const lng = window.localStorage.getItem("lng");

  const qualificationOptions = [
    { value: "Uneducated", label: "No Formal Education" },
    { value: "Below 5th Standard", label: "Below 5th Standard" },
    { value: "5th Standard Passed", label: "5th Standard Passed" },
    { value: "7th Standard Passed", label: "7th Standard Passed" },
    { value: "8th Standard Failed", label: "8th Standard Failed" },
    { value: "8th Standard Passed", label: "8th Standard Passed" },
    { value: "9th Standard Passed", label: "9th Standard Passed" },
    { value: "10th Standard Passed", label: "10th Standard Passed" },
    { value: "12th Standard", label: "12th Standard" },
    { value: "Below 12th Standard", label: "Below 12th Standard" },
    { value: "12th Passed - science", label: "12th Passed - science" },
    { value: "12th Passed - Non-science", label: "12th Passed - Non-science" },
    { value: "12th Standard Passed", label: "12th Standard Passed" },
    { value: "CSTI Certified", label: "CSTI Certified" },
    { value: "Diploma", label: "Diploma" },
    { value: "ITI", label: "ITI" },
    { value: "Professional", label: "Professional" },
    { value: "Degree", label: "Degree" },
    { value: "BSC - science", label: "BSC - science" },
    { value: "BSC - Non-science", label: "BSC - Non-science" },
    { value: "2 Years Diploma", label: "2 Years Diploma" },
    { value: "Bachelors Degree 2nd Year", label: "Bachelors Degree 2nd Year" },
    { value: "Bachelors Degree 3rd Year", label: "Bachelors Degree 3rd Year" },
    { value: "Bachelors Degree 4th Year", label: "Bachelors Degree 4th Year" },
    { value: "Bachelors Degree 5th Year", label: "Bachelors Degree 5th Year" },
    { value: "Graduate", label: "Graduate" },
    { value: "Masters Degree 1st Year", label: "Masters Degree 1st Year" },
    { value: "Masters Degree 2nd Year", label: "Masters Degree 2nd Year" },
    { value: "Post Graduate", label: "Post Graduate" },
  ];

  const genderOptions = [
    { value: "Male", label: "Male" },
    { value: "Female", label: "Female" },
    { value: "Others", label: "Others" },
  ];

  const districtOptions = [
    {value: "Enter Pinode", label: "Enter Pincode"},
    { value: "Ambala", label: "Ambala" },
    { value: "Bhiwani", label: "Bhiwani" },
    { value: "Charkhi Dadri", label: "Charkhi Dadri" },
    { value: "Faridabad", label: "Faridabad" },
    { value: "Fatehabad", label: "Fatehabad" },
    { value: "NorGurugram (Gurgaon)", label: "Gurugram (Gurgaon)" },
    { value: "Hisar", label: "Hisar" },
    { value: "Jhajjar", label: "Jhajjar" },
    { value: "Jind", label: "Jind" },
    { value: "Kaithal", label: "Kaithal" },
    { value: "Karnal", label: "Karnal" },
    { value: "Kurukshetra", label: "Kurukshetra" },
    { value: "Mahendragarh", label: "Mahendragarh" },
    { value: "Nuh", label: "Nuh" },
    { value: "Palwal", label: "Palwal" },
    { value: "Panchkula", label: "Panchkula" },
    { value: "Panipat", label: "Panipat" },
    { value: "Rewari", label: "Rewari" },
    { value: "Rohtak", label: "Rohtak" },
    { value: "Sirsa", label: "Sirsa" },
    { value: "Sonipat", label: "Sonipat" },
    { value: "Yamunanagar", label: "Yamunanagar" },
  ];


  const getStudentData = () => ({
    firstName,
    lastName,
    highestQualification,
    gender,
    dob,
    mobileNumber,
    pincode,
    address,
    village,
    district,
    mailId,
    language,
  });
  const selectDistrictRef = useRef();
  const selectVillageRef = useRef();
  const pincodeRef = useRef();
  const mailIdRef = useRef();

  var myDist = {}
  useEffect(() => {
    if(pincode.length === 6) {
      getDistrict(dispatch, jwtToken, pincode, errors?.pincode?.length);
    }
    if(district == ""){
      const error = errors["district"] = "* Mandatory field";
      setErrors(error);
      // setDistrict( (getDistrictName(cityVillageDetails).length!=0) ? getDistrictName(cityVillageDetails) : setErrors({error}))
    }
    if(mailId == ""){
      if(errors?.mailId!=""){
        const error = errors["mailId"] = "";
        setErrors(error);
      }
    }
  }, [pincode, district]);
  const saveStudent = (event) => {
    event.preventDefault();
    mailIdRef?.current?.focus();
    var error = {}
    if(district === "") {setDistrict(cityVillageDetails?.cityVillageList[0]?.district)}    
    const student = { ...getStudentData() };
    if( student.mailId==="" || (student.mailId !== "") && (validateMailId(student.mailId)?.mailId?.length<1) ){
      if (!validatePersonFormErrors(errors))
      if(student?.district?.length === 0 && cityVillageDetails?.cityVillageList[0]?.district !== undefined){
        createStudent(dispatch, jwtToken, student, cityVillageDetails?.cityVillageList[0]?.district);
      }
      else{
        createStudent(dispatch, jwtToken, student, student?.district);
      }
    }
    else{
      alert('Form has one or more errors please check to proceed')
    }
  };

  const onChangePincode = (event) => {
    if (event?.target?.value || event?.target?.value?.length === 0) {
      const errors = validatePincode(event?.target?.value, lng);
      setErrors(errors);
      setPincode(event?.target?.value);
    }
    if(pincode.length != 6) {
      setDistrict("");
      setVillage("");
      selectDistrictRef?.current?.select?.clearValue();
      selectVillageRef?.current?.select?.clearValue();
    };
  };


  const onChangeFirstName = (event) => {
    if (event?.target?.value || event?.target?.value?.length === 0) {
      const errors = validateTextInput("firstName", event?.target?.value, lng);
      setErrors(errors);
      setFirstName(event?.target?.value);
    }
  };

  const onChangeLastName = (event) => {
    if (event?.target?.value || event?.target?.value?.length === 0) {
      const errors = validateTextInput("lastName", event?.target?.value, lng);
      setErrors(errors);
      setLastName(event?.target?.value);
    }
  };

  const onChangeHighestQualification = (event) => {
    if (event?.value || event?.value?.length === 0) {
      const errors = validateSelectInput("highestQualification", event?.value);
      setErrors(errors);
      setQualification(event?.value);
    }
  };

  const onChangeGender = (event) => {
    if (event?.value || event?.value?.length === 0) {
      const errors = validateSelectInput("gender", event?.value);
      setErrors(errors);
      setGender(event?.value);
    }
  };

  const onChangeVillage = (event) => {
    if (event?.value || event?.value?.length === 0) {
      const errors = validateVillage(event?.value, lng);
      setErrors(errors);
      setVillage(event?.value);
    }
  };

  const onChangeDistrict = (event) => {
    if (event?.value || event?.value?.length === 0) {
      const errors = validateDistrict(event?.value, lng);
      setErrors(errors);
      setDistrict(event?.value);
    }
  };

  const onChangeMailId = (event) => {
    if (event?.target?.value || event?.target?.value?.length === 0) {
      const errors = validateMailId(event?.target?.value, lng);
      setErrors(errors);
      setMailId(event?.target?.value);
    }
  };

  const getVillageNameList = (cityVillageDetails) => {
    if (!cityVillageDetails) return [];
    if (!cityVillageDetails?.cityVillageList) return [];
    if(cityVillageDetails?.cityVillageList && Object.keys(cityVillageDetails?.cityVillageList).length === 0 && cityVillageDetails?.cityVillageList === Object)
      return []; 
    return cityVillageDetails?.cityVillageList.map(
      (villageNames) => ({
        value: villageNames.cityVillage,
        label: villageNames.cityVillage,
      })
    );
  };

  const getDistrictNameList = (cityVillageDetails) => {
    var DistrictList = [];
    if (!cityVillageDetails) return [];
    if (!cityVillageDetails?.cityVillageList) return [];
    if(cityVillageDetails?.cityVillageList && Object.keys(cityVillageDetails?.cityVillageList).length === 0 && cityVillageDetails?.cityVillageList === Object)
      return []; 
    cityVillageDetails?.cityVillageList?.map(
      (dataValue)=> {
        if(!DistrictList.find((value)=>value.label == dataValue.district)){
          DistrictList.push({
              value: dataValue.district,
              label: dataValue.district,
            })
        }
      });
    return DistrictList;
  };
  const getDistrictName = (cityVillageDetails) => {
    if (!cityVillageDetails) return "";
    if (!cityVillageDetails?.cityVillageList) return "";
    if (!cityVillageDetails?.cityVillageList[0]?.district) return "";
    return cityVillageDetails?.cityVillageList[0]?.district;
  };

  return (
    <div className="person_screen_body">
      <form  onSubmit={saveStudent}>
      <div className="bold-blue-heading center_aligned">{t('form_heading')}</div>
      <div class="required_header_text">{t('mandatoryFields')}</div>  
      
          <div className="person_screen_row">
            
            <div className="person_screen_column">
              <label for="firstName" className = "basicForm-label">{t('firstName')}<span class="mandatory"> * </span></label>
              <input className = "basicForm-input"  placeholder={t('firstNamePlaceHolder')}
                type = "text"   value={firstName}   maxLength= "25"   name="name"     required
                onChange={onChangeFirstName}               />
              {errors?.firstName ? (<div class="basic-input-error">{errors.firstName}</div>) : null} 
            </div>
            <div className="person_screen_column">
              <label for="lastName" className = "basicForm-label">{t('lastName')}<span class="mandatory" > * </span> </label>
              <input className = "basicForm-input"
                placeholder={t('lastNamePlaceHolder')}  value={lastName} maxLength= "25" name="name"  required
                onChange={(e) => onChangeLastName(e)}/>
              {errors?.lastName ? (<div class="basic-input-error">{errors.lastName}</div> ) : null}
            </div>

          </div> 
          
          
          <div class="person_screen_row"> 

            <div className="person_screen_column">
              <label for="qualification" className = "basicForm-label">{t('qualification')} <span class="mandatory"> * </span></label>
              <Select className = "basicForm-select"  options={qualificationOptions}  required
                onChange={(e) => onChangeHighestQualification(e)} />
              {errors?.highestQualification ? (<div class="basic-input-error">{errors.highestQualification}</div>) : null}
            </div>
            <div className="person_screen_column">
              <label for="gender" className = "basicForm-label">{t('gender')} <span class="mandatory"> * </span></label>
              <Select className = "basicForm-select"  options={genderOptions} required 
                onChange={(e) => onChangeGender(e)} />
              {errors?.gender ? ( <div class="basic-input-error">{errors.gender}</div> ) : null}
            </div>

          </div> 


          <div class="person_screen_row"> 
      
            <div className="person_screen_column">
              <label for="pincode" className = "basicForm-label">{t('pincode')} <span class="mandatory"> * </span></label>
              <input className = "basicForm-input" placeholder={t('pincodePlaceHolder')} value={pincode}
                maxLength="6"  name="pincode" required onChange={(e) => onChangePincode(e)} />
              {errors?.pincode ? ( <div class="basic-input-error">{errors.pincode}</div> ) : null}
            </div>
           {(pincode.length < 6 || pincode.length === 6) && getVillageNameList(cityVillageDetails).length === 0 && (
            <div className="person_screen_column">
            <label for="village" className = "basicForm-label">{t('village')}</label>
            <input className = "basicForm-input" placeholder={t('villagePlaceHolder')} type = "text" value={village} name="village" onChange={(e) => onChangeVillage(e?.target)} />
            {errors?.village ? (<div class="basic-input-error">{errors.village}</div>) : null}
            </div> )}
            {getVillageNameList(cityVillageDetails).length !== 0 && (
            <div className="person_screen_column">
              <label for="village" className = "basicForm-label">{t('village')}     </label>
              <Select className = "basicForm-select" ref={selectVillageRef}  options={getVillageNameList(cityVillageDetails)}  onChange={(e) => onChangeVillage(e)}/>
            </div>)}

          </div>

         



          <div class="person_screen_row"> 
    
          {getDistrictName(cityVillageDetails).length !== 0 && (
              <div className="person_screen_column">
                <label for="district" className = "basicForm-label">{t('district')} <span class="mandatory"> * </span></label>
                <Select className = "basicForm-select" placeholder={t('districtPlaceHolder')} required 
                  options={getDistrictNameList(cityVillageDetails)} 
                  ref={selectDistrictRef}
                  name="district" id="district1" onChange={(e) => onChangeDistrict(e)}/>
                  {errors?.district ? (<div class="basic-input-error">{errors.district}</div> ) : null}
              </div> )}
              {getDistrictName(cityVillageDetails).length === 0 && (
               <div className="person_screen_column">
                  <label for="district" className = "basicForm-label">{t('district')} <span class="mandatory"> * </span></label>
                    <Select className = "basicForm-select" placeholder={t('districtPlaceHolder')}  options={districtOptions} required isDisabled onChange={(e) => onChangeDistrict(e)} />
               {(pincode.length === 6 ) ? (<div class="basic-input-error">{t("invalidPincode")}</div> ) : null}
               </div> 
            )}








            <div className="person_screen_column">
              <label for="mailId" className = "basicForm-label">{t('mailId')}</label>
              <input className = "basicForm-input"   placeholder={t('mailIdPlaceHolder')} value={mailId} maxLength= "50" name="mailId" ref={mailIdRef} onChange={(e) => onChangeMailId(e)}  />
             {errors?.mailId ? (<div class="basic-input-error">{errors.mailId}</div>) : null}   
            </div>

          </div> 
          
          
          <div class="person_screen_row"> 

            <div className="person_screen_column">
              <label for="dob" className = "basicForm-label">{t('dob')}</label>
              <input value={userData?.dob} name="dob" disabled="true" className = "basicForm-input"/>
            </div>
            <div className="person_screen_column">
              <label for="mobileNumber" className = "basicForm-label">{t('mobileNumber')}</label>
              <input className = "basicForm-input"  value={userData?.mobileNumber} name="mobileNumber" disabled="true"/>
            </div>
          
          </div> 
          
          <div class="row_center">   
            <div>
            <div class="required_header_text">&nbsp;</div>   
            {(validatePersonFormErrors(errors)) ? (
              <div className="center_aligned"><button type="submit" class="submit-grey">{t('save')} </button></div>
            ) : (
              <div><button type="submit" class="submit-blue">{t('save')}</button> </div>
            )}
           </div>  
           <div class="required_header_text">&nbsp;</div>   
          </div>
            

      </form>      
    </div>
  );
};

export default PersonForm;
