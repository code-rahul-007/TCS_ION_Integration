import React, { useEffect, useState } from "react"; 
import firebase from "../services/firebase";
import Otp from "./Otp";
import '../css/signin.scss';
import './../assets/css/font-awesome.min.css'
import MobileNumber from "./MobileNumber";
import homeImage from './../assets/images/IMG_050.png';
import { useTranslation } from 'react-i18next';
import AlertDialog from './AlertDialog';

const SigninForm = (props) => {
  const {verifyMobileNumber} = props;
  const [confirm, setConfirm] = useState(null);
  const [userData, setuserData] = useState({});
  const { t, i18n } = useTranslation();
  const [language, setLanguage] = useState("en");
  const [alertMsg, setAlertMsg] = useState(false);


   useEffect(() => {   
    handleLanguageSelect(language)
   } , []);


 
 
  const handleClick = async (event, userData) => {
      event.preventDefault();
      setuserData(userData);
      const recaptcha = new firebase.auth.RecaptchaVerifier("recaptcha",{
        'size': 'invisible'});
      window.recaptcha = recaptcha;
      // Commented to Disable the OTP valication and passing empty object in setConfirm()
      // const confirmation = await firebase.auth().signInWithPhoneNumber(userData?.mobileNumber, recaptcha);
      setConfirm({});
      // confirmation);
  }

  const confirmVerificationCode = async (code) => {
    try {
      // Commented to Disable the OTP valication and passing empty object in setConfirm()
      // await confirm.confirm({});
        // code);
      const user  = {...userData, verified: true}
      setConfirm(null);  
      verifyMobileNumber(user);
    } catch (error) {
      verifyMobileNumber(userData);
      handleErrorCode();
    }
  }

  const handleLanguageSelect = (language) => {
    setLanguage(language);
    i18n.changeLanguage(language);
    window.localStorage.setItem("lng",language);
  } 

  const handleErrorCode = () => {
    setAlertMsg(true);
  }

  return (  
    <div class='home_body_c'>  
      <div class ="language">  
     
          <span><button className = "button_as_link" onClick = {(e) => handleLanguageSelect("en")}>English</button></span>
          
          <span className = "no_link_text">{"|"}</span>
      
       <span><button className = "button_as_link" 
       onClick = {(e) => handleLanguageSelect("hn")}>हिंदी</button>
       </span> 

      </div> 
      <div class='home_body' > 
        <div class="home_body_60">
          { !confirm ? <MobileNumber onClick={handleClick} language={language}/> :
          <Otp onSubmitCode={confirmVerificationCode} userData = {userData}/>}  
        </div>   
        <div class="home_body_40">   
          <img class = "home_img" src={homeImage} alt="logo"/>
        </div>  
      </div>
      {alertMsg && (
        <AlertDialog message={t('invalidCode')}></AlertDialog>
      )}
    </div>
  );
};

export default SigninForm;