import React, { useState, useEffect } from "react";
import InterestInventory from './InterestInventory';
import Alert from "./Alert";
import { useStateValue } from "../state";
import { getJwtTokenWithEngagementId } from "../actions/jwtTokenActions";
import { fetchCoursesByHollandCode } from "../actions/courseActions";
import { getInventoryDocumentDetails } from "../actions/documentActions";
import { viewInventoryData } from "../actions/interestInventoryActions";

import Header from './Header';
import Footer from './Footer';
import UserNotFound from './ErrorPage';
import '../css/main.scss';
import '../css/user-not-found.scss';

import ConfirmationDialog from "./ConfirmationDialog";

import domtoimage from "dom-to-image";
import '../css/InterestInventory.scss';
import { 
  codeExplanation,
  codeExplanationBg,
  videoSrc,videoSrcbg,
  videoSrcHn,codeExplanationHn
}from "../constants/inventoryConstants";
import {
    domtoImage,
} from "../actions/documentActions";
import Text from "@material-ui/core/FormHelperText";
import RowChart from "./RowChart";
import { resetState } from "../actions/homeAction";
import {hideConfirm, showConfirm, showResult, showChatbot} from "../actions/confirmAction";
import { useTranslation } from 'react-i18next';
import { findStudentByEngId, findStudentDetailsByUniqueId } from "../actions/studentActions";


const MainForURLParamEngID = (props) => {
  
  const [finalResultAvilable, setfinalResultAvilable] = useState();
  const [userData, setuserData] = useState({});
  const [{ jwtToken }, dispatch] = useStateValue();
  const [{ studentDetails }] = useStateValue();
  const [{ inventoryDetails }] = useStateValue();
  const [{ documentDetails }] = useStateValue();
  const [{ dialog }] = useStateValue();
  const [url, setUrl] = useState("");
  const { t, i18n } = useTranslation();
  const lng = i18n.language || window.localStorage.getItem("lng");
  const [{ courseDetails }] = useStateValue();
  const [renderView, setrenderView] = useState(false);
// alert(props?.props)
// console.log(props?.props)
  const collegeRegisterNo = props?.props;
  
  /*Incase student's engagement ID is provided inside the student details provide the data for engagement Id and call the student details there itself*/
  useEffect(() => {
    if (!jwtToken?.token){
      // alert('Not logged in')
      getJwtTokenWithEngagementId(dispatch, collegeRegisterNo);
      // findStudentDetailsByUniqueId(dispatch, jwtToken, collegeRegisterNo);
      // viewInventoryData(dispatch, jwtToken, studentDetails?.student?.engagementId );
    }
    // else if(!studentDetails?.student?.engagementId){
    //   // alert('student not found')
    //   // findStudentDetailsByUniqueId(dispatch, jwtToken, studentEngagementId)
    // }
    if (studentDetails?.student) {
      console.log("<============Student Details for a particular student==============>", studentDetails?.student)
      // viewInventoryData(dispatch, jwtToken, studentDetails?.student?.engagementId );
    }
    else{
      console.log('student Interest inventory data is not found!')
    }
    // if(studentDetails?.student){
    //   findStudentDetailsByUniqueId(dispatch, jwtToken, collegeRegisterNo)
    // }
  }, [studentDetails?.student]);

  // fetch courses based on hollandCode and verify for document details against the engagementId 
  // useEffect(() => {
  //   if(inventoryDetails?.inventory?.finalScore && studentDetails.student?.engagementId){
  //     fetchCoursesByHollandCode(dispatch, inventoryDetails?.inventory?.finalScore, jwtToken);
  //     getInventoryDocumentDetails(dispatch, studentDetails.student?.engagementId, jwtToken);
  //   }
  // }, [inventoryDetails?.inventory?.hollandCodeReverificationCode]);
  
  useEffect(()  =>  {
      if( studentDetails?.student?.engagementId!=null || studentDetails?.student?.engagementId!=undefined ){
        console.log("<============Student Details for a particular student==============>", studentDetails?.student)
      }
  }, [studentDetails?.student]);
  // useEffect(() => {
  //   if(documentDetails?.documentPath !== undefined && documentDetails?.documentPath?.length>0){
  //     setfinalResultAvilable(true);
  //     // console.log("<=================Student Details================>",studentDetails);
  //   }
  // }, [documentDetails?.basicDocId]);

  
  const getCodeText = (hollandCode) => {
    if(lng === "bg"){
      const letters = hollandCode.split('');
      const codeText = [];
      letters.map(letter => (
        codeText.push(codeExplanationBg.filter((l) => l.letter === letter))
      ));
      return codeText;
    }
  
    else if(lng === "hn"){
      const letters = hollandCode.split('');
      const codeText = [];
      letters.map(letter => (
        codeText.push(codeExplanationHn.filter((l) => l.letter === letter))
      ));
      return codeText;
    }
    else {
      const letters = hollandCode.split('');
      const codeText = [];
      letters.map(letter => (
        codeText.push(codeExplanation.filter((l) => l.letter === letter))
      ));
      return codeText;
    }
    
  };

/* save interest inventory document before moving to next page */
const handleResultPage = (event) => {
  event.preventDefault();
  if(documentDetails?.basicDocId === null || documentDetails?.basicDocId === undefined) {
    domtoimage.toPng(document.getElementById('chart'))
    .then((dataUrl) => {
    domtoImage(dispatch,studentDetails?.student?.dbUserId, studentDetails?.student?.engagementId, courseDetails?.courses, dataUrl, studentDetails?.student?.firstName, inventoryDetails?.inventory?.finalScore, jwtToken, lng);
    });
  }

  showConfirm(dispatch);
}

const onResultsDismiss = () => {
  hideConfirm(dispatch);
}
const onResultsConfirm = () => {
  hideConfirm(dispatch);
  setrenderView(false);
  showResult(dispatch);
}


  return ( 
    <div class="main_container"> 
    <table class="table_border_blue" width="100%">
      {/* header row */}
      <tr>
        <td>
      <div>
        <Header/>
      </div>
      </td>
      </tr>
      {/* central component row - background image */}
      <tr >
        <td >
      <div>
  
          <div>
            <div>{(studentDetails?.student ) && <UserNotFound />}</div>
            <div>{(!studentDetails?.student ) && <InterestInventory />}</div>

            {/* <div>
              {(studentDetails?.student?.engagementId && (inventoryDetails?.inventory?.finalScore === undefined || inventoryDetails?.inventory?.finalScore?.length === 0  || inventoryDetails?.inventory?.hollandCodeReverificationCode === undefined || !finalResultAvilable || dialog.enableReplay) )&&    
                <UserNotFound />
              }  
            </div>
            <div>
              {!(studentDetails?.student?.engagementId && (inventoryDetails?.inventory?.finalScore === undefined || inventoryDetails?.inventory?.finalScore?.length === 0  || inventoryDetails?.inventory?.hollandCodeReverificationCode === undefined || !finalResultAvilable || dialog.enableReplay) )&&    
                <InterestInventory />
              }  
            </div> */}

            {( ( inventoryDetails?.inventory?.finalScore !== undefined  && inventoryDetails?.inventory?.finalScore ?.length > 0 && (inventoryDetails?.inventory?.hollandCodeReverificationCode === undefined || inventoryDetails?.inventory?.hollandCodeReverificationCode.length === 0)) || (inventoryDetails?.inventory?.hollandCodeReverificationCode?.length > 0 && !dialog?.showResult) ) && (
      <div  className="container-padding" id="resultDiv">
        
        <div class = "results-bold-text"> {t('congratulations')} {studentDetails?.student?.firstName}! {t('lookAtResults')}  </div>
        <div class = "results-text-reduced"> {t('AfterGameMsg')} <span class="results-bold-text"> {inventoryDetails?.inventory?.finalScore} </span> </div>
        
        <div class="image_results_table" >
          <div  class="image_results_70 ">
          <table >
            {getCodeText(inventoryDetails?.inventory?.finalScore).map((item) => (
                <tr className= "inv-tr">
                  <td key = {item[0].letter}><Text class="results-text-reduced"> {item[0].letter} </Text></td> 
                  <td><Text class="results-text-reduced"> {":"}</Text></td>
                  <td key = {item[0].text}> <Text class="results-text-reduced">{item[0].text}</Text></td>
                </tr>
              ))}
          </table>
          </div> 
          <div   id="chart" >
            <RowChart data={inventoryDetails?.inventory?.gameResults} />
          </div>
        </div>

        


        <div className="alert_text-reduced row_center"> {t('watchCareerVideo')} </div>
          
          <div className="row_center">
            <iframe
              src= {url}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title="YouTube video player"
              width="90%"
              height="200px"
            /> 
          </div> 
        
        

        <div class = "results-text-reduced row_center"> <button type="submit" className = "submit-blue" onClick= {handleResultPage} >{t('clickHereButton')}</button> {t('knowMoreAboutMatchingCareers')} </div>            
        <div>
          {dialog.confirm && <ConfirmationDialog open = {true} title = {t('careervideoConfirmation')} onConfirm = {onResultsConfirm} onDismiss = {onResultsDismiss}></ConfirmationDialog>}
        </div> 
      </div>           
      
      )}


            {/* All are completed - display results */}
            <div>  
              {finalResultAvilable && !dialog.enableReplay && (
              <Alert/>
              )}
            </div>
      
          </div>   
        {/* ) */}
        {/* } */}
      </div>
      </td>
      </tr>
      {/* footer row */}
      <tr >
        <td >
      <div>
        <Footer />
      </div>
      </td>
      </tr>
      </table>
    </div>
  );
};

export default MainForURLParamEngID;
