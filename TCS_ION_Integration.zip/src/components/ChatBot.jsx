import React, { useEffect } from "react";
import { useStateValue } from '../state';
import "bootstrap/dist/css/bootstrap.min.css";
import { updateInterestInventoryCode } from "./../actions/interestInventoryActions";
import { showChatbot } from "../actions/confirmAction";
import { hideChatbot } from "../actions/confirmAction";
import ChatbotImage from './../assets/images/chatbot.png';
import { useTranslation } from 'react-i18next';

const ChatBot = () => {
const [{ inventoryDetails }] = useStateValue();
const [{ studentDetails }] = useStateValue();
const [{ jwtToken }, dispatch] = useStateValue();
const [{ dialog }] = useStateValue();
const { t, i18n } = useTranslation();
const lng = i18n.language || window.localStorage.i18nextLng;

useEffect(() => {
  if(dialog.showChatbot === true){
    const script = document.createElement('script');
    script.async = true;
    script.src = "static/js/dialogflow-bootstrap.js";
    document.body.appendChild(script);

    
    const dfMessenger = document.querySelector('df-messenger');
    dfMessenger.addEventListener('df-response-received', function (event) {
      var result=event.detail.response.queryResult.diagnosticInfo;
      var result1=event.detail.response.queryResult.outputContexts;
     
      var result2=result1[0].parameters;
          
      if (result.end_conversation==true){
        //alert("Thank you for your answers");
        var result3=result2.questions;
        var score = 0;
        for ( var i=0;i<result3.length;i++) {
          if(result3[i].score!=="NULL"){
            score+=parseInt(result3[i].score)
          }
        }
        
        
        updateInterestInventoryCode(dispatch, studentDetails?.student?.engagementId,jwtToken,inventoryDetails?.inventory?.finalScore,inventoryDetails?.result, inventoryDetails?.inventory?.id,score,"NO")
         .then(() => {
          hideChatbot(dispatch);  
        });

        
      }
    }); 

    window.addEventListener('dfMessengerLoaded', function (event) {
      const $r1 = document.querySelector("df-messenger");
      const $r2 = $r1.shadowRoot.querySelector("df-messenger-chat");
      //const $r4 = $r2.shadowRoot.querySelector("df-messenger-titlebar").shadowRoot.querySelector("div").querySelector("div").innerHTML ='<div><img height=45px; width=45px; src="/static/images/IMG-20210625-WA0007.jpg">eCounselling</div>'
    });


  }
}, [dialog.showChatbot]);




const enableChat = () => {
  showChatbot(dispatch); 
}



return (
  
  <div>
    
    { ( inventoryDetails?.inventory?.finalScore ?.length > 0 && (inventoryDetails?.inventory?.hollandCodeReverificationCode === undefined || inventoryDetails?.inventory?.hollandCodeReverificationCode.length === 0)  && !dialog.showChatbot ) && (
      <div class="row_center">   
        <div className = "bold-blue-heading">{t('ThankYouForPlayingGame')}</div>
        <div className = "text-reduced center_aligned"> {t('beforeChatBot')} </div>
        
        <div>
        <img class = "small_img" src={ChatbotImage} alt="Bot"/>
        </div>

        
        <div><button type="submit" className="submit-blue" onClick={enableChat}>{t('clickToStart')}</button></div>
        <div className = "text-reduced">&nbsp;</div>  
      </div>  
    )} 
    
    {dialog.showChatbotQuestions && (
        <div className = "bold-blue-heading">{t('chatbotHeading')}</div>
    )} 
    

    {dialog.showChatbotQuestions && (
      <div>     
        <df-messenger
          intent="WELCOME"
          chat-title="eCounselling"
          agent-id="a411c12a-bbf0-4ca6-80a4-058f0c72e67a"
          language-code="en"
          chat-icon="/static/images/chatbot.png"
          session-id= {studentDetails?.student?.engagementId +'$'+ studentDetails?.student?.firstName+'$'+inventoryDetails?.inventory?.finalScore+'$'+lng}
          expand="true">
        </df-messenger>
      </div>
      
    )}
   

   
  </div>

  );

}


export default ChatBot;