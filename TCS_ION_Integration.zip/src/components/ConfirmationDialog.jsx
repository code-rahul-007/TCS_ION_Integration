import React from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogActions from "@material-ui/core/DialogActions";
import Button from "@material-ui/core/Button";
import Text from "@material-ui/core/FormHelperText";
import { useTranslation } from 'react-i18next';

const ConfirmationDialog = (props) => {
  const {open, title, message, onDismiss, onConfirm} = props;
  const { t, i18n } = useTranslation(); 
  return (
    <Dialog open={open} onClose={onDismiss}>
      <DialogTitle><div ><Text style={{
          fontSize: '1.25rem',
          color : '#0868B3',
          fontFamily: 'Myriad Pro',
          }}>{message}{t('confirmDialog')}</Text></div></DialogTitle>
      <DialogContent>
        <DialogContentText><div><Text style={{
          fontSize: '1rem',
          color : 'black',
          fontFamily: 'Myriad Pro',
          }}>{title} </Text></div></DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button onClick={onDismiss}><Text style={{
          fontSize: '1rem',
          color : 'black',
          fontFamily: 'Myriad Pro',
          }}>{t('no')}</Text></Button>
        <Button color="primary" variant="contained" onClick={onConfirm}>
        <Text style={{
          fontSize: '1rem',
          color : 'black',
          fontFamily: 'Myriad Pro',
          }}>{t('yes')}</Text>
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ConfirmationDialog;