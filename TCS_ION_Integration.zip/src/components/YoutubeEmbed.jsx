import React from 'react';
import PropTypes from "prop-types";
import "../css/embedVideoStyle.scss";

const YoutubeEmbed = ({ embedId }) => {
    const src = 'https://www.youtube.com/embed/'+embedId+'?playlist='+embedId+'&loop=1';
    
    YoutubeEmbed.propTypes = {
        embedId: PropTypes.string.isRequired
    }
    
    return (
    <div className = "video-responsive">
        <iframe
            src= {src}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="YouTube video player"
        />
    </div>
);


};

export default YoutubeEmbed;