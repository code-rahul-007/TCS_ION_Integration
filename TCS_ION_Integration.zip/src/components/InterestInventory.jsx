import React, { useEffect } from "react";
import { useState } from "react";
import { useStateValue } from "../state";
import pics from "./../assets/pics.json";
import "./../assets/css/style.css";
import "./../assets/css/c3.min.css";
import "../css/InterestInventory.scss";
import "bootstrap/dist/css/bootstrap.min.css";
import Button from "@material-ui/core/Button";
import Text from "@material-ui/core/FormHelperText";
import {hideConfirm, showCourses} from "../actions/confirmAction";
import {
  icons, 
  responseJson,
}from "../constants/inventoryConstants";
import {
  saveInterestInventoryCode,
} from "./../actions/interestInventoryActions";
import { useTranslation } from 'react-i18next';

const InterestInventory = () => {
  const [{ jwtToken }, dispatch] = useStateValue();
  const [{ inventoryDetails }] = useStateValue();
  const [{ studentDetails }] = useStateValue();
  const [imageLength, setImageLength] = useState(0);
  const [error, setError] = useState("");
  const [clickCounter, setClickCounter] = useState(0);
  const [one, setOne] = useState({});
  const [photocount, setPhotoCount] = useState(42);
  const [allImages, setAllImages] = useState([]);
  const [imagePath, setImagePath] = useState({});
  const [backshow, setBackshow] = useState(false);
  const { t, i18n } = useTranslation();
  const lng = i18n.language || window.localStorage.getItem("lng");

  window.localStorage.clear();

  console.log(" From Int Inv Page URL ", process.env.PUBLIC_URL)
 
  useEffect(() => {
    var host = window.location.host;
    if (!window.localStorage.hasOwnProperty("path")) {
      window.localStorage.setItem("path", host + "/Decosystem");
    }
    if (!window.localStorage.hasOwnProperty("photocount")) {
      window.localStorage.setItem("photocount", 42);
    }
    if (!window.localStorage.hasOwnProperty("icons")) {
      window.localStorage.setItem("icons", JSON.stringify(icons));
    }
    nextImg();
    play();

  }, []);

  useEffect(() => {
    setImagePath(allImages[clickCounter]);
  }, [allImages]);


  // logic to generate HollandCode based on the user response to images
  const generateCode = (dataToCheck) => {
    var cat = ["Y", "N", "N", "N", "N", "N"];
    
    var addLike = function (c) {
      var category = c.category;
      category.forEach(function (d, i) {
        if (d === "Y") {
          responseJson[i].count = responseJson[i].count + 1;
          responseJson[i].like = responseJson[i].like + 1;
        }
      });
    };

    var addUnlike = function (c) {
      var category = c.category;
      category.forEach(function (d, i) {
        if (d === "Y") {
          responseJson[i].unlike = responseJson[i].unlike - 1;
        }
      });
    };

    var addConfused = function (c) {
      var category = c.category;
      category.forEach(function (d, i) {
        if (d === "Y") {
          responseJson[i].neutral = responseJson[i].neutral + 1;
        }
      });
    };
    
    dataToCheck.forEach(function (d, i) {
      switch (d.response) {
        case "like":
          addLike(d);
          break;
        case "unlike":
          addUnlike(d);
          break;
        case "confused":
          addConfused(d);
          break;
      }
    });

    var responseJson2 = responseJson.slice();
  
    //sort in descending order based likes only count in decending order
    responseJson.sort(function (a, b) {
      if (a.count < b.count) {
        return 1;
      }
      if (a.count > b.count) {
        return -1;
      }
      // a must be equal to b , then check for Unlikes. Unlikes are Negatives
      if(a.count === b.count){
       if (a.unlike < b.unlike) {
       return 1;
        }
        if (a.unlike > b.unlike) {
        return -1;
        }
       return 0;
      }
    });

    
    var topThree = responseJson.slice(0, 3);
  
    // If any likes count are equal in top 3, then check for unlikes count to change the order
  /* commenting out these possiblities as they are already handled in the prev. condition (if a = b)  
    // Possibility 1 - If all three are same
    if (topThree[0].like === topThree[1].like &&  topThree[1].like === topThree[2].like && topThree[0].like === topThree[2].like ) {
      topThree.sort(function (a, b) {
        if (a.unlike < b.unlike) {
          return 1;
        }
        if (a.unlike > b.unlike) {
          return -1;
        }
        // a must be equal to b
        return 0;
      });
    }
    
    // Possibility 2 - one and two are same
    if (topThree[0].like === topThree[1].like )  {
      if( topThree[0].unlike > topThree[1].unlike){
        var temp = topThree[0].like;
        topThree[0].like = topThree[1].like;
        topThree[1].like = temp;
      }
    }
    // Possibility 3 - two are three are same
    if (topThree[1].like === topThree[2].like)  {
      if( topThree[1].unlike > topThree[2].unlike){
        var temp = topThree[1].like;
        topThree[1].like = topThree[2].like;
        topThree[2].like = temp;
      }
    } */
  
    // Final Result of Interest Inventory Game
    var result = "",  jo = {};
      
      
    topThree.forEach(function (d, i) {
        if (i < 3) result = result + d.letter;
    });
      
    if (result === "") {
      result = "No Interests";
    }

    jo.result = result;
    jo.data = responseJson2;
    
    saveInterestInventoryCode(dispatch, studentDetails?.student?.engagementId, jwtToken, jo.result, jo.data);
  };

  const UniqueArraybyOccupation = (collection, keyname) => {
    let output = [],
      keys = [];
    collection.map((item) => {
      let key = item[keyname];
      if (keys.indexOf(key) === -1) {
        keys.push(key);
        output.push(item);
      }
    });
    return output;
  };

  const shuffleArray = (categoryImagesArray) => {
    for (var n = 0; n < categoryImagesArray.length - 1; n++) {
      let k = n + Math.floor(Math.random() * (categoryImagesArray.length - n));
      var temp = categoryImagesArray[k];
      categoryImagesArray[k] = categoryImagesArray[n];
      categoryImagesArray[n] = temp;
    }
    return categoryImagesArray;
  };

  const removeArrayElements = (categoryImagesArray) => {
    for (var n = 0; n < categoryImagesArray.length; n++) {
      if (categoryImagesArray.length > 7) {
        var k =
          n + Math.floor(Math.random() * (categoryImagesArray.length - n));
        categoryImagesArray.splice(k, 1);
      } else {
        break;
      }
    }
    return categoryImagesArray;
  };

  const nextImg = (event, userResponse) => {

    var oneImage = imagePath;
    oneImage.response = userResponse; 
    allImages[clickCounter] = oneImage;
    setAllImages(allImages => ([...allImages]));

    //loading next image or generate result
    if (clickCounter == allImages.length || clickCounter == photocount) {
      // transfer to opinion page
      var jo = { play: allImages }; 
       generateCode((allImages));
    } else {
      //loading next image
      setClickCounter(clickCounter + 1);
      setImagePath(allImages[clickCounter]);
    }
  };

  const onImagesLoaded = () => {
    var images = pics;
    var categoryA = UniqueArraybyOccupation(
      shuffleArray(images.A),
      "Occupation"
    );
    var categoryC = UniqueArraybyOccupation(
      shuffleArray(images.C),
      "Occupation"
    );
    var categoryE = UniqueArraybyOccupation(
      shuffleArray(images.E),
      "Occupation"
    );
    var categoryI = UniqueArraybyOccupation(
      shuffleArray(images.I),
      "Occupation"
    );
    var categoryR = UniqueArraybyOccupation(
      shuffleArray(images.R),
      "Occupation"
    );
    var categoryS = UniqueArraybyOccupation(
      shuffleArray(images.S),
      "Occupation"
    );
    var imagesArray = removeArrayElements(categoryA);
    imagesArray = imagesArray.concat(removeArrayElements(categoryC));
    imagesArray = imagesArray.concat(removeArrayElements(categoryE));
    imagesArray = imagesArray.concat(removeArrayElements(categoryI));
    imagesArray = imagesArray.concat(removeArrayElements(categoryR));
    imagesArray = imagesArray.concat(removeArrayElements(categoryS));

    /********* Fisher–Yates_shuffle ******/
    for (var n = 0; n < imagesArray.length - 1; n++) {
      var k = n + Math.floor(Math.random() * (imagesArray.length - n));

      var temp = imagesArray[k];
      imagesArray[k] = imagesArray[n];
      imagesArray[n] = temp;
    }
    /*************************************/
    setAllImages(allImages => ([...imagesArray]));
    setImageLength(imagesArray.length);
    setImageLength(imagesArray - 1);

    let imagePathTemp = allImages[clickCounter];
    setImagePath(imagePathTemp);

    const goBack = function () {
      //loading prev image
      setClickCounter(clickCounter - 1);
      if (clickCounter < 0) {
        setClickCounter(0);
        setBackshow(true);
      }

      setImagePath(allImages[clickCounter]);
    };
  };

  const onError = () => {
    setError("Not able To load images");
  };

  const play = () => {
    var active = function () {
      var questionTo = JSON.parse(window.localStorage.getItem("icons"));
      var one;
      questionTo.forEach(function (val) {
        if ((val.active) && (val.lng === lng)) {
          one = val;
        }
      });
      return one;
    };

    setPhotoCount(photocount - 1);

    let isVisible = true;
    setClickCounter(0);
    setOne(active());
    setBackshow(true);
    let startTime = new Date().getTime();
    var test = onImagesLoaded(photocount);

  };


  return (
    <div>
    {/* Game results doesnts exists - Show Game */}
    { (inventoryDetails?.inventory?.finalScore === undefined || inventoryDetails?.inventory?.finalScore.length === 0 ) && (
      <div>
          <div class="game-bold-text"><center>{one?.question}</center></div>
          <div className="image_body_col">
            <div className="image_body_row">
              <img  class="playImage img-responsive" src={process.env.PUBLIC_URL + "/iImages/" + imagePath.description}
                data-text={process.env.PUBLIC_URL +"/iImages/" +imagePath.description }/>
              <p>{error}</p>
            </div>
            <div className="image_body_row">
              <div className="image_body">
                <Button  class="nonebtn" value="like" onClick={(e) => nextImg(e, "like")}>
                  <img class="responseImage" src={process.env.PUBLIC_URL + "/icons/" + one.img1}/>
                  <Text class="centertext"> {t('like')} </Text>
                </Button>
              </div>
              <div className="image_body">
                <Button class="nonebtn" value="unlike" onClick={(e) => nextImg(e, "unlike")}>
                  <img class="responseImage" src={ process.env.PUBLIC_URL + "/icons/" + one.img2}/>
                  <Text class="centertext">{t('dislike')}</Text>
                </Button>
              </div>
              <div className="image_body">
                <Button class="nonebtn" value="confused" onClick={(e) => nextImg(e, "confused")}>
                  <img class="responseImage" src={ process.env.PUBLIC_URL + "/icons/" + one.img3}/>
                  <Text class="centertext">{t('mayBe')}</Text>
                </Button>
              </div>
            </div>
          </div>
      </div>
    )}
 
    </div>
  );
}

export default InterestInventory;
