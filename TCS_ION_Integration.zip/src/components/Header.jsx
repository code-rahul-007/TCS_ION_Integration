import React from 'react';
import '../css/header.scss';
import wbLogo from '../assets/images/WBLogo.png';
import ubLogo from '../assets/images/UBLogo.png';
import { useTranslation } from 'react-i18next';
const Header = () => {
    const { t, i18n } = useTranslation();
return(

<header class="main-header">
	<div class="header_container">
        <div class="container_left">
            <img class = "img" src={wbLogo} alt="logo"/>
        </div>
        <div class="container_left">
            <div class= "text">{t('heading')}</div> 
            <div class= "sub-text">{t('subHeading')}</div>
        </div>
        <div class="container_right">
        <img class = "img" src={ubLogo}alt="logo"/>
        </div>
	</div>
</header>
 )
}
export default Header;