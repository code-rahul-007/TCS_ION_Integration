import React, { createContext, useContext, useReducer } from "react";
import PropTypes from "prop-types";

export const StateContext = createContext();

export const StateProvider = ({ reducer, initialState = {}, children }) => (
  <StateContext.Provider value={useReducer(reducer, initialState)}>
    {children}
  </StateContext.Provider>
);

StateProvider.propTypes = {
  reducer: PropTypes.func.isRequired,
  children: PropTypes.element,
  initialState: PropTypes.object, // eslint-disable-line react/forbid-prop-types
}

export const useStateValue = () => useContext(StateContext);