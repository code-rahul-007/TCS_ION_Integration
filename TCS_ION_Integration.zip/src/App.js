import Main from './components/Main';
import React from "react";
import { BrowserRouter, Route, Switch, useLocation } from "react-router-dom";
import { StateProvider } from "./state";
import reducer from "./reducer";
import ReactGA from 'react-ga';
import UserNotFound from './components/ErrorPage';
import URLParamLandingPage from './components/URLParamLandingPage';


function initializeReactGA() {
  ReactGA.initialize('UA-123791717-1');
  ReactGA.pageview('/homepage');
}
var URLdata = window.location.href+"";
// alert(URLdata)

const App = () => {
  // let query = useQuery();
  return (
    <StateProvider reducer={reducer}>
      {/* Uncomment the code below if we do not want anything incase of URL parameters */}
      {/* <BrowserRouter>
            <Switch>
            <Route
                exact
                path={["/?EngId=:EngagementId"]}
                component={ 
                  // Main}
                  // AlternateMain}
                  SampleLandingPage} 
                // URLdata.includes('?EngId=') ? (<SampleLandingPage/>) : (<Main/>)
                // }      
              />
              {/* <Route
                exact
                path={["/"]}
                component={ 
                  Main}
                  // AlternateMain}
                  // SampleLandingPage} 
                // URLdata.includes('?EngId=') ? (<SampleLandingPage/>) : (<Main/>)
                // }      
              /> 
            </Switch>
      </BrowserRouter> */}
     { URLdata.includes('?Id=') ? <URLParamLandingPage/> : <UserNotFound/> }
    </StateProvider> 
  )
}

export default App
