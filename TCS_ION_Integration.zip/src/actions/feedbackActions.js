import {
    SAVE_FEEDBACK_REQUEST,
    SAVE_FEEDBACK_SUCCESS,
    SAVE_FEEDBACK_FAILURE,
} from "../constants/actionTypes";
import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';

/* API call to enable feedback from the user */
export const saveFeedback = async(dispatch, engagementId, jwtToken, feedback) => {
    dispatch({type: SAVE_FEEDBACK_REQUEST});
        let requestFormData = new FormData();
        requestFormData.append('data', '{"token" : "", "action" : "createFeedbackDetails", "data" : [{"engagementId":"' +engagementId + '","feedback":"'+ feedback+'"}]}');
        return fetchRequestWithHeader(serviceEndPoint.feedbackServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
            response.status ==='success' ? dispatch({type: SAVE_FEEDBACK_SUCCESS, response}) :
            dispatch({ type: SAVE_FEEDBACK_FAILURE, response });       
        })
        .catch(() => Promise.reject(dispatch({ type: SAVE_FEEDBACK_FAILURE })));
            
}