import {
    RESET_STATE_REQUEST
} from "../constants/actionTypes";
export const resetState  = (dispatch) => {
    return dispatch({ type: RESET_STATE_REQUEST });  
  }
