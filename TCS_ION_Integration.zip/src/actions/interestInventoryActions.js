import {
    VALIDATE_INTEREST_INVENTORY_REQUEST,
    VALIDATE_INTEREST_INVENTORY_SUCCESS,
    VALIDATE_INTEREST_INVENTORY_FAILURE,
    SAVE_INTEREST_INVENTORY_CODE_REQUEST,
    SAVE_INTEREST_INVENTORY_CODE_SUCCESS,
    SAVE_INTEREST_INVENTORY_CODE_FAILURE,
    SAVE_CONNECT_COUNSELLOR_REQUEST,
    SAVE_CONNECT_COUNSELLOR_SUCCESS,
    SAVE_CONNECT_COUNSELLOR_FAILURE,
    VALIDATE_INVENTORY_FOR_CHATSCORE_REQUEST,
    VALIDATE_INVENTORY_FOR_CHATSCORE_SUCCESS,
    VALIDATE_INVENTORY_FOR_CHATSCORE_FAILURE,
    UPDATE_INTEREST_INVENTORY_CODE_REQUEST,
    UPDATE_INTEREST_INVENTORY_CODE_SUCCESS,
    UPDATE_INTEREST_INVENTORY_CODE_FAILURE,
    SAVE_CALL_BACK_URL_REQUEST,
    SAVE_CALL_BACK_URL_SUCCESS,
    SAVE_CALL_BACK_URL_FAILURE,
    
} from "../constants/actionTypes";
import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';
import { findStudentByEngId, findStudentDetailsByUniqueId } from "../actions/studentActions";
import domtoimage from "dom-to-image";

/* validate the given engagement ID against any available IntInvCode */
export const viewInventoryData  = (dispatch, jwtToken, engId) => {
    dispatch({ type: VALIDATE_INTEREST_INVENTORY_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append('data', '{"token" : "", "action" : "viewInterestInventoryByEngId", "data" : [{"engagementId":' + engId + '}]}');
    return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
        response.status === 'failure' ? dispatch({ type: VALIDATE_INTEREST_INVENTORY_FAILURE, response }) :
        dispatch({ type: VALIDATE_INTEREST_INVENTORY_SUCCESS, response });
    })
      .catch(() => Promise.reject(dispatch({ type: VALIDATE_INTEREST_INVENTORY_FAILURE })));
  }

/* save IntInvCode against the given engagementId */
export const saveInterestInventoryCode = async(dispatch,engagementId, jwtToken, finalScore, joResult) => {
    dispatch({ type: SAVE_INTEREST_INVENTORY_CODE_REQUEST });
    let requestFormData = new FormData();;
    let jsonstring = JSON.stringify(joResult);
    jsonstring = jsonstring.replace(/\"/g, '~'); 

    requestFormData.append('data', '{"token" : "", "action" : "captureInterestInventory", "data" : [{"engagementId":' + engagementId + ',"gameResults":"' + jsonstring + '","finalScore":"' + finalScore + '","createdBy":'+ jwtToken.user.id+'}]}');
     return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
        response = {...response, joResult};
        response.status === 'failure' ? dispatch({type: SAVE_INTEREST_INVENTORY_CODE_FAILURE, response }) :
        dispatch({ type: SAVE_INTEREST_INVENTORY_CODE_SUCCESS, response });
        })
        .catch(() => Promise.reject(dispatch({ type: SAVE_INTEREST_INVENTORY_CODE_FAILURE })));

} 

/* update chat score against the given engagementId */
export const updateInterestInventoryCode = async(dispatch,engagementId, jwtToken, finalScore, jsonstring,iiID,hcReverificationCode,connectCounselor
    ) => {
    dispatch({ type: UPDATE_INTEREST_INVENTORY_CODE_REQUEST });
    let requestFormData = new FormData();;
    requestFormData.append('data', '{"token" : "", "action" : "captureInterestInventory", "data" : [{"engagementId":' + engagementId + ', "connectCounselor":"'+connectCounselor+'" ,"hollandCodeReverificationCode":"' + hcReverificationCode + '","id":"' + iiID + '","gameResults":"' + jsonstring + '","finalScore":"' + finalScore + '","createdBy":'+ jwtToken.user.id+'}]}');
     return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
        response = {...response};
        response.status === 'failure' ? dispatch({type: UPDATE_INTEREST_INVENTORY_CODE_FAILURE, response }) :
        dispatch({ type: UPDATE_INTEREST_INVENTORY_CODE_SUCCESS, response });
        })
        .catch(() => Promise.reject(dispatch({ type: UPDATE_INTEREST_INVENTORY_CODE_FAILURE })));

} 

/* save enable counsellor option against the given user */
export const SaveConnectCounsellor = async(dispatch, engagementId, jwtToken, finalScore, connectCounsellor) => {
    dispatch({ type: SAVE_CONNECT_COUNSELLOR_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append('data', '{"token" : "", "action" : "captureInterestInventory", "data" : [{"engagementId":' + engagementId + ',"connectCounselor":"' + connectCounsellor + '","finalScore":"' + finalScore + '","createdBy":'+ jwtToken.user.id+'}]}');
    return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
       response.status === 'failure' ? dispatch({type: SAVE_CONNECT_COUNSELLOR_FAILURE, response }) :
       dispatch({ type: SAVE_CONNECT_COUNSELLOR_SUCCESS, response });
       })
       .catch(() => Promise.reject(dispatch({ type: SAVE_CONNECT_COUNSELLOR_FAILURE })));
}

/* validate the given engagement ID & FinalScore against any available hollandCodeReverificationCode(chatbot score)  */
export const viewInventoryDataForChatBotScore  = (dispatch, jwtToken, engId) => {
    dispatch({ type: VALIDATE_INVENTORY_FOR_CHATSCORE_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append('data', '{"token" : "", "action" : "viewInterestInventoryByEngId", "data" : [{"engagementId":' + engId + '}]}');
    return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
        response.status === 'failure' ? dispatch({ type: VALIDATE_INVENTORY_FOR_CHATSCORE_FAILURE, response }) :
        dispatch({ type: VALIDATE_INVENTORY_FOR_CHATSCORE_SUCCESS, response });
    })
      .catch(() => Promise.reject(dispatch({ type: VALIDATE_INVENTORY_FOR_CHATSCORE_FAILURE })));
  }

/*Call back URL for posting the data on to thier end*/
export const callBackURLForSavingTheData = (dispatch, jwtToken, hollandCode, uniqueId, engagementId) => {
    dispatch({ type: SAVE_CALL_BACK_URL_REQUEST });
    // return fetch('https://qahf.digialm.com//EducationGenericBizapps/CCWS?ck=DaXmpkL56e&data={"requestData":{"token":"123TYSBBD","userId":"10000090","apiAction":"callback","data":[{"id":49,"hollandcode":"SAC","course":"ArtDirector","createdBy":1,"createdOn":"Nov29,2021","coursePath":"https://www.tatastrive.com/Courses.html","trade":"Media\\u0026Entertainment"}]}}')
    // .then((response)=>{ console.log('<==========RESPONSE SUCCESS=========>',response) 
    //     dispatch({ type: SAVE_CALL_BACK_URL_SUCCESS, response })
    // }).catch(() => Promise.reject(dispatch({ type: SAVE_CALL_BACK_URL_FAILURE })) );
    console.log('Inside the call back url a step above the return')
    return null;
}