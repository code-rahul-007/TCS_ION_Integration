import {
    SAVE_INTEREST_INVENTORY_DOC_REQUEST,
    SAVE_INTEREST_INVENTORY_DOC_SUCCESS,
    SAVE_INTEREST_INVENTORY_DOC_FAILURE,
    DOWNLOAD_DOC_REQUEST,
    DOWNLOAD_DOC_SUCCESS,
    DOWNLOAD_DOC_FAILURE,
    FIND_DOCUMENT_BY_ENGAGEMENT_REQUEST,
    FIND_DOCUMENT_BY_ENGAGEMENT_SUCCESS,
    FIND_DOCUMENT_BY_ENGAGEMENT_FAILURE,
    DELETE_DOC_REQUEST,
    DELETE_DOC_SUCCESS,
    DELETE_DOC_FAILURE,
} from "../constants/actionTypes";
import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';

/* save the generated IntInvDocument against the given DbUserId */
export const domtoImage = (dispatch, dbUserId, engagementId, coursesOfHollandCode, dataUrl, benificiaryName, intInvFinnalScore, jwtToken, language) => {
        dispatch({type: SAVE_INTEREST_INVENTORY_DOC_REQUEST});
            let requestFormData = new FormData();
            
            //requestFormData.append('data', '{"token" : "", "action" : "saveInterestInventoryDocument", "data" : [{"dbUserId":'+dbUserId+',"engagementId":'+engagementId+',"documentType":"InterestInventory","typeOfDocument":"P","documentName":"InterestInventory","base64File":"'+dataUrl+'","coursesOfHollandCode":"'+coursesOfHollandCode+'","benificiaryName":"'+benificiaryName+'","hollandCode":"'+intInvFinnalScore+'"}]}');
            
            requestFormData.append('data', '{"token" : "", "action" : "saveInterestInventoryDocumentLanguageSpecific", "data" : [{"dbUserId":'+dbUserId+',"engagementId":'+engagementId+',"documentType":"InterestInventory","typeOfDocument":"P","documentName":"InterestInventory","base64File":"'+dataUrl+'","coursesOfHollandCode":"'+coursesOfHollandCode+'","benificiaryName":"'+benificiaryName+'","hollandCode":"'+intInvFinnalScore+'","language":"'+language+'"}]}');
            return fetchRequestWithHeader(serviceEndPoint.documentServiceEndPoint, requestFormData, jwtToken.token ).then((response) => { 
                response.status === 'success' ? dispatch({ type: SAVE_INTEREST_INVENTORY_DOC_SUCCESS, response }) :
                dispatch({ type: SAVE_INTEREST_INVENTORY_DOC_FAILURE, response });
            
            }) 
            .catch(() => Promise.reject(dispatch({ type: SAVE_INTEREST_INVENTORY_DOC_FAILURE })));      
}

export const downloadInterestInventoryDocument = async(dispatch, basicDocId, jwtToken) => {
    
        dispatch({type: DOWNLOAD_DOC_REQUEST});
            let requestFormData = new FormData();
            requestFormData.append('data', '{"token" : "", "action" : "downloadDocument", "data" : [{"basicDocId":"' +basicDocId + '"}]}');
            return fetchRequestWithHeader(serviceEndPoint.documentServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
                response.status ==='success' ? dispatch({type: DOWNLOAD_DOC_SUCCESS, response}) :
                dispatch({ type: DOWNLOAD_DOC_FAILURE, response });
                return response;
                
            })
            .catch(() => Promise.reject(dispatch({ type: DOWNLOAD_DOC_FAILURE })));
                
}

export const deleteInterestInventoryDocument = async(dispatch, basicDocId, jwtToken) => {
    
    dispatch({type: DELETE_DOC_REQUEST});
        let requestFormData = new FormData();
        requestFormData.append('data', '{"token" : "", "action" : "deleteDocument", "data" : [{"basicDocId":"' +basicDocId + '"}]}');
        return fetchRequestWithHeader(serviceEndPoint.documentServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
            response.status ==='success' ? dispatch({type: DELETE_DOC_SUCCESS, response}) :
            dispatch({ type: DELETE_DOC_FAILURE, response });
            return response;
            
        })
        .catch(() => Promise.reject(dispatch({ type: DELETE_DOC_FAILURE })));
            
}

export const getInventoryDocumentDetails = async(dispatch, engagementId, jwtToken) => {
    
    dispatch({type: FIND_DOCUMENT_BY_ENGAGEMENT_REQUEST});
        let requestFormData = new FormData();
        requestFormData.append('data', '{"token" : "", "action" : "fetchDocumentDetailsByEngagementIdAndDocumentType", "data" : [{"engagementId":"' +engagementId + '", "documentName":"InterestInventory","typeOfDocument":"P"}]}');
        return fetchRequestWithHeader(serviceEndPoint.documentServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
            response.status ==='success' ? dispatch({type: FIND_DOCUMENT_BY_ENGAGEMENT_SUCCESS, response}) :
            dispatch({ type: FIND_DOCUMENT_BY_ENGAGEMENT_FAILURE, response });
            return response;
            
        })
        .catch(() => Promise.reject(dispatch({ type: FIND_DOCUMENT_BY_ENGAGEMENT_FAILURE })));
            
}
