import {
GET_DISTRICT_REQUEST,
GET_DISTRICT_SUCCESS,
GET_DISTRICT_FAILURE 
} from "../constants/actionTypes";

import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';
export const getDistrict  = async (dispatch, jwtToken, pincode, pincodeErrors) => {
    dispatch({ type: GET_DISTRICT_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append("data", '{"token" : "", "action" : "findpincode", "data" :[{"pincode":"'+pincode+'"}]}'); 
    let response = {data:'[]'};
    if(pincode.length === 6 && pincodeErrors === 0){
        return fetchRequestWithHeader(serviceEndPoint.cityVillageServiceEndPoint, requestFormData,jwtToken.token ).then((response) => {
            dispatch({ type: GET_DISTRICT_SUCCESS, response });})
          .catch(() => Promise.reject(dispatch({ type: GET_DISTRICT_FAILURE })));
    }else{
        dispatch({ type: GET_DISTRICT_FAILURE, response });
    }

  }