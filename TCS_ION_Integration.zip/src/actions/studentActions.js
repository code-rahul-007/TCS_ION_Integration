import {
    VALIDATE_STUDENT_REQUEST,
    VALIDATE_STUDENT_SUCCESS,
    VALIDATE_STUDENT_FAILURE,
    CREATE_STUDENT_REQUEST,
    CREATE_STUDENT_SUCCESS,
    CREATE_STUDENT_FAILURE,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_FAILURE,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_SUCCESS,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_REQUEST,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_REQUEST,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_SUCCESS,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_FAILURE,
} from "../constants/actionTypes";
import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';
import { viewInventoryData } from "../actions/interestInventoryActions";


export const getEngagementId  = async (dispatch, jwtToken, userData) => {
    dispatch({ type: VALIDATE_STUDENT_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append("data", '{"token" : "", "action" : "searchByDobAndPrimaryContactNumber", "data" :[{"dob":"'+userData?.dob+'", "primaryContactNumber":"'+userData?.mobileNumber+'"}]}');  
    return fetchRequestWithHeader(serviceEndPoint.studentServiceEndPoint, requestFormData,jwtToken.token ).then((response) => {
        dispatch({ type: VALIDATE_STUDENT_SUCCESS, response });
        return response.data})
      .catch(() => Promise.reject(dispatch({ type: VALIDATE_STUDENT_FAILURE })));
  }


  export const createStudent  = async (dispatch, jwtToken, student, districtValue) => {
    dispatch({ type: CREATE_STUDENT_REQUEST });
    let requestFormData = new FormData();
    const language=student?.language;
    /* call to fetch dbUserId on saving the new student user */
    requestFormData.append('data','{"token" : " ", "action" : "captureBeneficiaryDetails", "data" : [{"gender":"'+student?.gender+'","firstName":"'+student?.firstName+'","lastName":"'+student?.lastName+'","highestQualification":"'+student?.highestQualification+'","primaryContactNumber":'+student?.mobileNumber+',"primaryEmailId":"'+student?.mailId+'","dob":"'+student?.dob+'", "creationChannel":"SR-HR-Samagra"}]}'); 
    return fetchRequestWithHeader(serviceEndPoint.studentServiceEndPoint, requestFormData,jwtToken.token ).then((response) => {
        if(response.status=== 'success') {
            let jsonData = JSON.parse(response.data)[0]
            const { dbUserId } = jsonData
            requestFormData = new FormData();
            /* request generated engagementId for the new student user */
            requestFormData.append('data','{"token" : "", "action" : "captureStudentEngagement", "data" :[{"dbUserId"  : ' + dbUserId + ' , "centerId" : ' + process.env.REACT_APP_CENTERID + ', "createdBy" : ' + process.env.REACT_APP_USERID + ', "remarks" : "","status" : "mobilised"}]}');
            fetchRequestWithHeader(serviceEndPoint.engagementServiceEndPoint, requestFormData,jwtToken.token).then((engagementServiceResponse) => {
                    if(engagementServiceResponse.status === 'success'){
                        const engagementServiceResponseData = JSON.parse(engagementServiceResponse.data)[0]
                        const { engagementId } = engagementServiceResponseData;
                        jsonData = {...jsonData, engagementId, language};
                        const data = JSON.stringify(jsonData);
                        response = {...response, data};
                        requestFormData = new FormData();
                        /* call to save address for the given pincode */
                        requestFormData.append('data','{"token" : "", "action" : "captureAddress", "data" :[{"createdBy" : ' + process.env.REACT_APP_USERID + ' , "isActive":"Y", "type":"R", "pincode": ' + student?.pincode + ', "addressLine1": "' + student?.address + '","addressLine2":"", "district":"' + districtValue + '","state":"Haryana","cityName":"Haryana","villageName":"' + student?.village + '","entityId":' + dbUserId + ',"entityType":"S"}]}');
                        fetchRequestWithHeader(serviceEndPoint.addressServiceEndPoint, requestFormData,jwtToken.token).then((pincodeServiceResponse) => {
                            pincodeServiceResponse.status === 'success' ? dispatch({ type: CREATE_STUDENT_SUCCESS, response }) : dispatch({ type: CREATE_STUDENT_FAILURE })
                        }
                        )
                    }else dispatch({ type: CREATE_STUDENT_FAILURE })
                }
            )

        }else{

            dispatch({ type: CREATE_STUDENT_FAILURE });
        }
        })
      .catch(() => Promise.reject(dispatch({ type: CREATE_STUDENT_FAILURE })));
  }

  export const findStudentByEngId = async (dispatch, jwtToken, engagementId) => {
      console.log("<===========JWT TOKEN==========>",jwtToken)
      dispatch({ type: FIND_STUDENT_DETAILS_BY_ENGAGEMENT_REQUEST });
      let requestFormData = new FormData();
      requestFormData.append('data', '{"token" : "", "action" : "viewStudentEngagementById", "data" : [{"engagementId": '+engagementId+' }]}');
      fetchRequestWithHeader(serviceEndPoint.engagementServiceEndPoint, requestFormData, jwtToken).then((responseDbUserStatus)=>{
            var resultDbuserStatus = JSON.parse(responseDbUserStatus.data)[0]
            console.log('<========result_Dbuser_Status========>',resultDbuserStatus)
            let studentReason = resultDbuserStatus.reason;
            let studentStatus = resultDbuserStatus.status;
            let studentdbUserId = resultDbuserStatus.dbUserId;
            requestFormData = new FormData();
            requestFormData.append('data', '{"token" : "'+ "1234" +'", "action" : "'+  "viewBeneficiaryDetailsById" +'", "data" : [{"dbUserId" : ' + studentdbUserId + '}]}');
            fetchRequestWithHeader(serviceEndPoint.studentServiceEndPoint, requestFormData, jwtToken).then((responseStudentService)=>{
                let resultStudentService = JSON.parse(responseStudentService.data)[0]
                let response = {dbUserId: studentdbUserId, dob: resultStudentService.dob,  engagementId: engagementId, 
                                firstName: resultStudentService.firstName, lastName: resultStudentService.lastName,
                                middleName: resultStudentService.middleName, primaryContactNumber: resultStudentService.primaryContactNumber,
                                remarks: studentReason, status: studentStatus};
                console.log('<=========Student Data=========>',response)
                dispatch({type: FIND_STUDENT_DETAILS_BY_ENGAGEMENT_SUCCESS, response});
                return response
            }).catch(()=>{ Promise.reject(dispatch({type: FIND_STUDENT_DETAILS_BY_ENGAGEMENT_FAILURE})) })
      }).catch(()=>{ Promise.reject(dispatch({type: FIND_STUDENT_DETAILS_BY_ENGAGEMENT_FAILURE})) })
    }

    /*this will be the service that aligns the unique code passed by TCS iON it returns */
   export const findStudentDetailsByUniqueId = async (dispatch, jwtToken, uniqueId) => {
        console.log("<============Unique ID=============>",uniqueId)
        dispatch({ type: FIND_STUDENT_DETAILS_BY_UNIQUEID_REQUEST });
        let requestFormData = new FormData();
        requestFormData.append('data', '{"token" : "", "action" : "getStudentDetailsByUniqueId", "data" : [{"collegeRegisterNo": '+uniqueId+' }]}');
        fetchRequestWithHeader(
            // serviceEndPoint.studentServiceEndPoint,
            "http://localhost:8081/student" ,
            requestFormData, jwtToken).then((responseUniqueStatus)=>{
                if(responseUniqueStatus?.status=='failure'){
                    dispatch({type: FIND_STUDENT_DETAILS_BY_UNIQUEID_FAILURE})
                    return null
                }
            console.log("<=======Response for Student new service=======>\t", responseUniqueStatus.data)
            var studentFound = JSON.parse(responseUniqueStatus.data)[0]
            console.log("<=======Response for Student new service if studnet is found=======>\t", studentFound)
            dispatch({type: FIND_STUDENT_DETAILS_BY_UNIQUEID_SUCCESS, studentFound})
            viewInventoryData(dispatch, jwtToken, studentFound?.engagementId )
            return getEngagementId(dispatch, jwtToken, studentFound)
            // findStudentByEngId(dispatch, jwtToken, studentFound.engagementId)
            // return studentFound
        }).catch(()=>{ Promise.reject(dispatch({type: FIND_STUDENT_DETAILS_BY_UNIQUEID_FAILURE})) })

   }
