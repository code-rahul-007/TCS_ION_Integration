import {
    SHOW_CONFIRM,
    HIDE_CONFIRM,
    SHOW_COURSES,
    SHOW_RESULT,
    SHOW_COURSES_FOR_ALERTPAGE,
    SHOW_CHATBOT,
    HIDE_CHATBOT,
    ENABLE_REPLAY,
} from "../constants/actionTypes";
export const showConfirm  = (dispatch) => {
    return dispatch({ type: SHOW_CONFIRM });  
}


export const hideConfirm  = (dispatch) => {
    return dispatch({ type: HIDE_CONFIRM });  
}

export const showCourses = (dispatch) => {
    return dispatch({ type: SHOW_COURSES });
}

export const showCoursesAlert = (dispatch) => {
    return dispatch({ type: SHOW_COURSES_FOR_ALERTPAGE });
}

export const showResult = (dispatch) => {
    return dispatch({ type: SHOW_RESULT });
}


export const showChatbot = (dispatch) => {
    return dispatch({ type: SHOW_CHATBOT });
}

export const hideChatbot = (dispatch) => {
    return dispatch({ type: HIDE_CHATBOT });
}

export const enableReplay = (dispatch) => {
    return dispatch({ type: ENABLE_REPLAY });
}


