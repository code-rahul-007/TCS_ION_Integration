import {
    FIND_COURSES_BY_HOLLANDCODE_REQUEST,
    FIND_COURSES_BY_HOLLANDCODE_SUCCESS,
    FIND_COURSES_BY_HOLLANDCODE_FAILURE,
} from "../constants/actionTypes";
import { fetchRequestWithHeader } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';


/* fetch relevant courses based on the HollandCode */
export const fetchCoursesByHollandCode = async(dispatch, hollandCode, jwtToken) => {
    dispatch({ type: FIND_COURSES_BY_HOLLANDCODE_REQUEST });
    let requestFormData = new FormData();
    requestFormData.append('data', '{"token" : "", "action" : "findCoursesByHollandCode", "data" : [{"hollandcode":"'+hollandCode+'"}]}');
    return fetchRequestWithHeader(serviceEndPoint.interestinventoryServiceEndPoint, requestFormData, jwtToken.token ).then((response) => {
        response.status === 'success' ? dispatch({ type: FIND_COURSES_BY_HOLLANDCODE_SUCCESS, response }) :
        dispatch({ type: FIND_COURSES_BY_HOLLANDCODE_FAILURE, response });
        return response;
        })
        .catch(() => Promise.reject(dispatch({ type: FIND_COURSES_BY_HOLLANDCODE_FAILURE })));
}
