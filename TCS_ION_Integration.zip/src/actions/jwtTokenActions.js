import {
    GET_TOKEN_REQUEST,
    GET_TOKEN_SUCCESS,
    GET_TOKEN_FAILURE
} from "../constants/actionTypes";
import { fetchRequest } from "../utils/fetchRequest";
import { serviceEndPoint } from '../utils/serviceEndPoint';
import { findStudentByEngId, findStudentDetailsByUniqueId } from "../actions/studentActions";

export const getJwtToken  = (dispatch) => {
    dispatch({ type: GET_TOKEN_REQUEST });
     let requestFormData = new FormData();
     const token = "";
     const action = "login";
     requestFormData.append('data', '{"token" : "'+token+'", "action" : "'+action+'", "data" : [{"userName":"'+process.env.REACT_APP_USER_NAME+'","password":"'+process.env.REACT_APP_PASSWORD +'"}]}');  
     return fetchRequest(serviceEndPoint.loginService, requestFormData).then((response) => {console.log(response);    
         dispatch({ type: GET_TOKEN_SUCCESS, response })})
       .catch(() => Promise.reject(dispatch({ type: GET_TOKEN_FAILURE })));
}

// export const getJwtTokenWithEngagementId  = (dispatch, uniqueId) => {
//    dispatch({ type: GET_TOKEN_REQUEST });
//     let requestFormData = new FormData();
//     const token = "";
//     const action = "login";
//     requestFormData.append('data', '{"token" : "'+token+'", "action" : "'+action+'", "data" : [{"userName":"'+process.env.REACT_APP_USER_NAME+'","password":"'+process.env.REACT_APP_PASSWORD +'"}]}');  
//     return fetchRequest(serviceEndPoint.loginService, requestFormData).then((response) => {console.log(response);    
//         let jsonobjects = JSON.parse(response.data);
//         let tokenGwt = jsonobjects[0].token;
//         // findStudentByEngId(dispatch, tokenGwt, engagementId)
//         dispatch({ type: GET_TOKEN_SUCCESS, response })})
//       .catch(() => Promise.reject(dispatch({ type: GET_TOKEN_FAILURE })));
//   }

  export const getJwtTokenWithEngagementId  = (dispatch, engagementId) => {
    dispatch({ type: GET_TOKEN_REQUEST });
     let requestFormData = new FormData();
     const token = "";
     const action = "login";
     requestFormData.append('data', '{"token" : "'+token+'", "action" : "'+action+'", "data" : [{"userName":"'+process.env.REACT_APP_USER_NAME+'","password":"'+process.env.REACT_APP_PASSWORD +'"}]}');  
     return fetchRequest(serviceEndPoint.loginService, requestFormData).then((response) => {console.log(response);    
         let jsonobjects = JSON.parse(response.data);
         let tokenGwt = jsonobjects[0].token;
        //  findStudentByEngId(dispatch, tokenGwt, engagementId)
         findStudentDetailsByUniqueId(dispatch, tokenGwt, engagementId)
         dispatch({ type: GET_TOKEN_SUCCESS, response })})
       .catch(() => Promise.reject(dispatch({ type: GET_TOKEN_FAILURE })));
   }


