import studentDetails from "./reducers/studentReducer";
import jwtToken from "./reducers/jwtTokenReducer";
import inventoryDetails from "./reducers/inventoryReducer";
import cityVillageDetails from "./reducers/cityVillageReducer";
import documentDetails from "./reducers/documentReducer";
import courseDetails from "./reducers/coursesReducer";
import dialog from "./reducers/confirmReducer";
import feedbackDetails from "./reducers/feedbackReducer";
import {
  RESET_STATE_REQUEST,
} from "./constants/actionTypes";

const combineReducers = reducersObject =>
  ( state, action ) => {
    const nextState = { ...state };
    Object.keys( reducersObject ).forEach( key => {
      nextState[ key ] = reducersObject[ key ]( nextState[ key ], action )
    });

    if(action.type=== RESET_STATE_REQUEST) return {
      ...state,
      inventoryDetails: null,
      studentDetails: null,
      token: "",
      user: null,
      cityVillageDetails: null,
      documentDetails: null,
      basicDocId: null,
      courseDetails: null,
      objectsFromHollandCode: null,
      courses: null,
      trades: null,
      result: null,
      dialog: false,
      feedbackDetails: null,
    };

    return nextState;
  };

export default combineReducers({
  studentDetails,
  jwtToken,
  inventoryDetails,
  cityVillageDetails,
  documentDetails,
  courseDetails,
  dialog,
  feedbackDetails,
});
