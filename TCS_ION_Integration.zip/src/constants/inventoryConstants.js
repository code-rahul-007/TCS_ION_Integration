export const icons = [
  {id: 0, question: " Would you Like to become ", img1: "like.png", img2: "unlike.png", img3: "confused.png", active: false, lng:"en"},
  {id: 1, question: " Do you like this?", img1: "like.png", img2: "unlike.png", img3: "confused.png", active: true, lng:"en"},
  {id: 2, question: " আপনি কি এটা পছন্দ করেন?", img1: "like.png", img2: "unlike.png", img3: "confused.png", active: true, lng:"bg"},
  {id: 3, question: " आप बनना चाहते हैं", img1: "like.png", img2: "unlike.png", img3: "confused.png", active: false, lng:"hn"},
  {id: 4, question: " क्या आपको यह पसंद है ?", img1: "like.png", img2: "unlike.png", img3: "confused.png", active: true, lng:"hn"},
];

export const responseJson = [
    {
      catId: 1,
      category: "Realistic",
      letter: "R",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
    {
      catId: 2,
      category: "Investigative",
      letter: "I",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
    {
      catId: 3,
      category: "Artistic",
      letter: "A",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
    {
      catId: 4,
      category: "Social",
      letter: "S",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
    {
      catId: 5,
      category: "Enterprising",
      letter: "E",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
    {
      catId: 6,
      category: "Conventional",
      letter: "C",
      count: 0,
      like: 0,
      unlike: 0,
      neutral: 0,
    },
  ];

export const codeExplanation = [
    {letter: 'A', text: "Artistic (creative, original, independent, chaotic, inventive)"},
    {letter: 'I', text: "Investigative(analytical, intellectual, scientific, explorative, thinker)"},
    {letter: 'S', text: "Social(cooperative, supporting, helping, healing/nurturing, teaching)"},
    {letter: 'R', text: "Realistic (practical, physical, concrete, hands-on, machine, and tool-oriented)"},
    {letter: 'C', text: "Conventional (detail-oriented, organizing, clerical)"},
    {letter: 'E', text: "Enterprising (competitive, leadership, persuading)"},
];
export const codeExplanationBg = [
  {letter: 'A', text: "আর্টিস্টিক/শৈল্পিক (সৃজনশীল, নিজস্বতা, স্বাধীনচেতা, বিশৃঙ্খল, উদ্ভাবক)"},
  {letter: 'I', text: "ইনভেস্টিগেটিভ (বিশ্লেষণাত্মক, বুদ্ধিমান, বিজ্ঞান্মনস্ক, অনুসন্ধানী, ভাবুক)"},
  {letter: 'S', text: "সোশ্যাল/সামাজিক (সহযোগী, সমর্থক, সাহায্যকারী, পালনকারী, শিক্ষাপ্রদানকারী)"},
  {letter: 'R', text: "রিয়েলিস্টিক/ বাস্তবিক (বাস্তববাদী, শারীরিক, দৃঢ়, সমর্পিত, যান্ত্রিক, যন্ত্র সম্পর্কিত)"},
  {letter: 'C', text: "কনভেনশনাল (সংগঠক, বিস্তারিত, কেরানি)"},
  {letter: 'E', text: "এন্টারপ্রাইসিং/উদ্যোগী ( প্রতিযোগিতামূলক,  নেতৃত্ব প্রদানকারী, বাচক)"},
];

export const codeExplanationHn = [
  {letter: 'A', text: "कलात्मक ( रचनात्मक , वास्तविक , आत्मनिर्भर , अस्तव्यस्त , अविष्कारक)"},
  {letter: 'I', text: "खोजी (विश्लेषक , बौद्धिक , वैज्ञानिक , अनुसंधानात्मक , विचारक )"},
  {letter: 'S', text: "सामाजिक ( सहयोगी , मददगार , सहायक , उपचारात्मक , सिखाने वाला)"},
  {letter: 'R', text: "वास्तविक ( व्यावहारिक , शारीरिक , पूर्ण , हाथ द्वारा , मशीन और साधन उन्मुखी )"},
  {letter: 'C', text: "पारम्परिक ( विस्तार उन्मुखी , व्यवस्थित , लिपिक )"},
  {letter: 'E', text: "उद्यमशील ( प्रतियोगी, नेतृत्व , राजी करने वाला )"},
];

export const videoSrc = [
    {letter: 'A', source: "_ZhA1IpuKYo"},
    {letter: 'I', source: "K3aANx53Kco"},
    {letter: 'S', source: "4HkGVq4FtAs"},
    {letter: 'R', source: "cN3XZs8cGpg"},
    {letter: 'C', source: "qdpvpo1dSl0"},
    {letter: 'E', source: "dpsR3TUrJog"},
];

export const videoSrcHn = [
  {letter: 'A', source: "Tc7cRjBOZhc"},
  {letter: 'I', source: "Cw-sfYgQpjw"},
  {letter: 'S', source: "boYQvidz4go"},
  {letter: 'R', source: "zMB4h6d5VL4"},
  {letter: 'C', source: "EJ1JQ6UAbAs"},
  {letter: 'E', source: "ef_3OVzkkYY"},
];

export const videoSrcbg = [
  {letter: 'A', source: "_ZhA1IpuKYo"},
  {letter: 'I', source: "K3aANx53Kco"},
  {letter: 'S', source: "4HkGVq4FtAs"},
  {letter: 'R', source: "cN3XZs8cGpg"},
  {letter: 'C', source: "qdpvpo1dSl0"},
  {letter: 'E', source: "dpsR3TUrJog"},
];
