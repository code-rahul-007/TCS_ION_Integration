import { LocalSee } from '@material-ui/icons';
import i18n from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import { initReactI18next } from 'react-i18next';
import { translation_en } from './translations/en/translation_en';
import { translation_bg } from './translations/bg/translation_bg';
import { translation_hn } from './translations/hn/translation_hn';

i18n
  // detect user language
  // learn more: https://github.com/i18next/i18next-browser-languageDetector
  .use(LanguageDetector)
  // pass the i18n instance to react-i18next.
  .use(initReactI18next)
  // init i18next
  // for all options read: https://www.i18next.com/overview/configuration-options
  .init({
    whitelist: ['hn','bg', 'en'],
    fallbackLng: 'en',
    debug: true,

    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
    resources: {
      en: {
        translation:translation_en
      },
      bg: {
        translation: translation_bg
      },
      hn: {
        translation: translation_hn
      }
    }
  });

export default i18n;