const fetchRequest = (url, data, token) => {
  return fetch(url,{
      method: "POST",
      body: data,
      }).then(response => {
      if (response.ok) {
          return response.json();
      }
      else{
          Promise.reject();
      }
  });
};


const fetchRequestWithHeader = (url, data, token) => {
    return fetch(url,{
        method: "POST",
        headers: {
            'Authorization': 'Bearer '+token
        }, 
        body: data,
        }).then(response => {
        if (response.ok) {
            Promise.resolve();
            return response.json();
        }
        else{
            Promise.reject();
        }
    });
  };

export {fetchRequest, 
    fetchRequestWithHeader};
