import i18n from 'i18next';

const lang = i18n.language || window.localStorage.getItem("lng");
let REQUIRED = "* Mandatory Field";
lang === "bg" ? REQUIRED = "* বাধ্যতামূলক" : REQUIRED = "* Mandatory Field";
const errors = {};

export function validateMobileNumber(mobileNumber, lng) {
    if(mobileNumber.length > 0 && mobileNumber.length < 10 )
    {
        lng === "bg" ? errors["mobileNumber"] =  "* ১০ সংখ্যা" : errors["mobileNumber"] =  "* Exactly 10 digits";
        
        return errors;
    }

    errors["mobileNumber"] =  mobileNumber.length === 0 ?  REQUIRED : "";
    return errors;
}

export function validatePincode(pincode, lng) {
    
    if(pincode.length < 6)
    {
        lng === "bg" ? errors["pincode"] = "* ৬ সংখ্যা" : errors["pincode"] = "* Exactly 6 digits";
        return errors;
    }
    if(!pincode.match(/^[0-9\b]+$/))
    {
       lng === "bg" ? errors["pincode"] =  "* শুধুমাত্র সংখ্যা" : errors["pincode"] =  "* Only Numbers";

        return errors
    }
    errors["pincode"] = pincode === "" ?  REQUIRED : "";
    
    return errors;
}

export function validateOtp(otp, lng) {
    
    if(otp.length < 6)
    {
        lng === "bg" ? errors["otp"] = "* ৬ সংখ্যা" : errors["otp"] = "* Exactly 6 digits";
        return errors;
    }
    if(!otp.match(/^[0-9\b]+$/))
    {
       lng === "bg" ? errors["otp"] =  "* শুধুমাত্র সংখ্যা" : errors["otp"] =  "* Only Numbers";

        return errors
    }
    errors["otp"] = otp === "" ?  REQUIRED : "";
    
    return errors;
}

export function validateTextInput(key, value, lng) {
    if(value.match(/[0-9\b]+$/))
    {
        lng === "bg" ? errors[key] =  "* শুধুমাত্র অক্ষর" : errors[key] =  "* Only Alphabets";

        return errors
    }
    if(value.match(/[`!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~]/))
    {
       lng === "bg" ? errors[key] = "* বিশেষ চিহ্ন-র প্রয়োজন নেই" : errors[key] = "* shouldnt include special characters";

        return errors;
    }
    errors[key] = value === "" ?  REQUIRED :  "";
    
    return errors;
}

export function validateDistrict(district, lng) {
    
    if(district.match(/[`!@#$%^&*+\=[\]{};':"\\|,<>/?~]/))
    {
        lng === "bg" ? errors["district"] = "* বিশেষ চিহ্ন-র প্রয়োজন নেই" : errors["district"] = "* shouldnt include special characters";

        return errors;
    }
    errors["district"] = district === "" ?  REQUIRED :  "";
    
    return errors;
}

export function validateVillage(village, lng) {
    
    if(village.match(/[`!@#$%^&*()_+\=[\]{};':"\\|,<>/?~]/))
    {
        lng === "bg" ? errors["village"] = "* বিশেষ চিহ্ন-র প্রয়োজন নেই" : errors["village"] = "* shouldnt include special characters";

        return errors;
    }
    errors["village"] = village === "" ?  REQUIRED :  "";
    
    return errors;
}

export function validateSelectInput(key, value) {
   
    errors[key] = value === "" ?  REQUIRED :  "";
    
    return errors;
}

export function validateAddress(address) {

    errors["address"] = address === "" ?  "" :  "";
    
    return errors;
}

export function validateMailId(mailId,lng) {
    if(mailId === "" || mailId == ""){
        errors["mailId"] = "";
        return errors;
    }
    else{
        if(! mailId.match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/))
        {
            lng === "bg" ? errors["mailId"] = "* ভুল ইমেল আইডি" : errors["mailId"] = "* Invalid mail Id";
            return errors;
        }
        errors["mailId"] = mailId === "" ?  "" :  "";
        return errors;
    }   
}
export function validateDOB(dob, lng) {
    
    var birthYear = (new Date(dob)).getFullYear();
    var currentYear = (new Date()).getFullYear();
    let dobError = "";
    lng === "bg" ? dobError = "* কমপক্ষে ১৬ বছরের অধিক হতে হবে" : dobError = "* Age should be more than 16 years" ;
    
    errors["dob"] = currentYear - birthYear < 16 ? dobError : "";

    return errors;
}

export function validateMobileNumberErrors(errors) {
    if(errors && Object.keys(errors).length === 0 && errors.constructor === Object){
        return true; 
    };
    if(errors?.mobileNumber?.length === 0 && errors?.dob?.length === 0){
        return false; 
    };

    return true;

    
}

export function validateOtpErrors(errors) {
    if(errors && Object.keys(errors).length === 0 && errors.constructor === Object){
        return true; 
    };
    if(errors?.otp?.length === 0){
        return false; 
    };

    return true;

}

export function validatePersonFormErrors(errors) {
    if(errors && Object.keys(errors).length === 0 && errors.constructor === Object) return true;
    if(errors?.firstName?.length === 0 &&
         errors?.lastName?.length === 0 && 
         errors?.highestQualification?.length === 0  &&
          errors?.gender?.length === 0  &&
         errors?.pincode?.length === 0 &&
          errors?.mailId?.length === 0 && 
          errors?.district?.length === 0) 
          return false;    return true;
        }
    