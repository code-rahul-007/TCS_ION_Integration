import {
    SAVE_FEEDBACK_REQUEST,
    SAVE_FEEDBACK_SUCCESS,
    SAVE_FEEDBACK_FAILURE,
} from "../constants/actionTypes";

const initialState = {
};
export default function feedbackReducer(state = initialState, action = {}) {
    const { type, response } = action;
    switch (type) {
        case SAVE_FEEDBACK_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case SAVE_FEEDBACK_SUCCESS: { 
            let responseJson = JSON.parse(response.data); 
            return {
              ...state,
              feedback: responseJson[0],
              loading: false,
              
          };
        }
        case SAVE_FEEDBACK_FAILURE:
          return {
            ...state,
            loading: false,
          };
            
        default:
        return state;
    }
}