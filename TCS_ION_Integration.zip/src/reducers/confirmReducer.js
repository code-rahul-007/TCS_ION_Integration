import {
    SHOW_CONFIRM,
    HIDE_CONFIRM,
    SHOW_COURSES,
    SHOW_RESULT,
    SHOW_COURSES_FOR_ALERTPAGE,
    SHOW_CHATBOT,
    HIDE_CHATBOT,
    ENABLE_REPLAY,
  } from "../constants/actionTypes";
  const initialState = {
  };
  export default function confirmReducer(state = initialState, action = {}) {
      const { type } = action;    
      switch (type) {
          case SHOW_CONFIRM:
            return {
              ...state,
              loading: false,
              confirm: true,
            };
          case HIDE_CONFIRM: {
            return {
              ...state,
              loading: false,
              confirm: false,
            };
          }
          case SHOW_COURSES: {
            return {
              ...state,
              loading: false,
              showCourses: true,
            }
          }
          case SHOW_RESULT: {
            return {
              ...state,
              loading: false,
              showResult: true,
            }
          }
          case SHOW_COURSES_FOR_ALERTPAGE: {
            return {
              ...state,
              loading: false,
              showCoursesForAlert: true,
            }
          }
          case SHOW_CHATBOT: {
            return {
              ...state,
              loading: false,
              showChatbot: true,
              showChatbotQuestions: true,
              
            }
          }
          case HIDE_CHATBOT: {
            return {
              ...state,
              loading: false,
              showChatbot: false,
              showChatbotQuestions: false,
            }
          }
          case ENABLE_REPLAY: {
            return {
              ...state,
              loading: false,
              enableReplay: true,
              showResult: false,
            }
          }
          
          default:
          return state;
      }
  }