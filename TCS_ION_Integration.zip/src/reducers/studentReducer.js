import {
    VALIDATE_STUDENT_REQUEST,
    VALIDATE_STUDENT_SUCCESS,
    VALIDATE_STUDENT_FAILURE,
    CREATE_STUDENT_REQUEST,
    CREATE_STUDENT_SUCCESS,
    CREATE_STUDENT_FAILURE,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_FAILURE,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_SUCCESS,
    FIND_STUDENT_DETAILS_BY_ENGAGEMENT_REQUEST,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_REQUEST,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_SUCCESS,
    FIND_STUDENT_DETAILS_BY_UNIQUEID_FAILURE,
} from "../constants/actionTypes";
const initialState = {
};
export default function StudentReducer(state = initialState, action = {}) {
    const { type, response } = action;
    switch (type) {
        case VALIDATE_STUDENT_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case VALIDATE_STUDENT_SUCCESS: {
          const data = JSON.parse(response.data);
          let student = (data && Object.keys(data).length === 0 && data.constructor === Object) ? JSON.parse(response.data) : JSON.parse(response.data)[0];
          if(!student) student = {...JSON.parse(response.data)}
          student = !student ? {...JSON.parse(response.data)} : student
          return {
            ...state,
            student: student,
            loading: false,
          };
        }
        case VALIDATE_STUDENT_FAILURE:
          return {
            ...state,
            loading: false,
          };
        
        case CREATE_STUDENT_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case CREATE_STUDENT_SUCCESS: {
          return {
            ...state,
            student: JSON.parse(response.data)[0],
            loading: false,
          };
        }
        case CREATE_STUDENT_FAILURE:
          return {
            ...state,
            languageSaved: false,
            loading: false,
          };
          /*this if for fetching the students details based on engagementId*/
          case FIND_STUDENT_DETAILS_BY_ENGAGEMENT_REQUEST: {
            console.log('<==============Inside the request for student details by engagement Id==============>')
            return {
              ...state,
              loading: true,
            };
          }
          case FIND_STUDENT_DETAILS_BY_ENGAGEMENT_SUCCESS: {
            console.log('<==============Inside the success for student details  by engagement Id==============>',response)
            // var dataResponse = JSON.parse(response.data)[0];
            return {
              ...state,
              student: response,
              loading: false,
            };
          }
          case FIND_STUDENT_DETAILS_BY_ENGAGEMENT_FAILURE: {
            console.log('<==============Inside the FAILURE for student details  by engagement Id==============>')
            return {
              ...state,
              // student: JSON.parse(response.data)[0],
              loading: false,
            };
          }
           /*this if for fetching the students details based on UniqueId*/
           case  FIND_STUDENT_DETAILS_BY_UNIQUEID_REQUEST: {
            console.log('<==============Inside the request for student details by unique Id==============>')
            return {
              ...state,
              loading: true,
            };
          }
          case   FIND_STUDENT_DETAILS_BY_UNIQUEID_SUCCESS: {
            console.log('<==============Inside the success for student details by Unique Id==============>',response)
            // var dataResponse = JSON.parse(response.data)[0];
            return {
              ...state,
              student: response,
              loading: false,
            };
          }
          case  FIND_STUDENT_DETAILS_BY_UNIQUEID_FAILURE: {
            console.log('<==============Inside the FAILURE for student details by Unique Id==============>')
            return {
              ...state,
              // student: JSON.parse(response.data)[0],
              loading: false,
            };
          }
        default:
        return state;
    }
}