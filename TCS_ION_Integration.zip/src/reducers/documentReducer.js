import {
  SAVE_INTEREST_INVENTORY_DOC_REQUEST,
  SAVE_INTEREST_INVENTORY_DOC_SUCCESS,
  SAVE_INTEREST_INVENTORY_DOC_FAILURE,
  DOWNLOAD_DOC_REQUEST,
  DOWNLOAD_DOC_SUCCESS,
  DOWNLOAD_DOC_FAILURE,
  FIND_DOCUMENT_BY_ENGAGEMENT_REQUEST,
  FIND_DOCUMENT_BY_ENGAGEMENT_SUCCESS,
  FIND_DOCUMENT_BY_ENGAGEMENT_FAILURE,
  DELETE_DOC_REQUEST,
  DELETE_DOC_SUCCESS,
  DELETE_DOC_FAILURE,
} from "../constants/actionTypes";
const initialState = {
};
export default function documentReducer(state = initialState, action = {}) {
    const { type, response } = action;
    switch (type) {
        case SAVE_INTEREST_INVENTORY_DOC_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case SAVE_INTEREST_INVENTORY_DOC_SUCCESS: {
          let responseJson = JSON.parse(response.data);  
            return {
              ...state,
              basicDocId: responseJson[0]!== undefined?responseJson[0].basicDocId:null,
              documentSaved: true,
              loading: false,
              
          };
        }
        case SAVE_INTEREST_INVENTORY_DOC_FAILURE:
          return {
            ...state,
            loading: false,
            documentSaved: false,
          };

        /* two */
        case DOWNLOAD_DOC_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case DOWNLOAD_DOC_SUCCESS: {
          let responseJson = JSON.parse(response.data);
            return {
              ...state,
              documentPath: responseJson[0].documentPath,
              downloadedDoc: true,
              loading: false,
              
          };
        }
        case DOWNLOAD_DOC_FAILURE:
          return {
            ...state,
            loading: false,
            downloadedDoc: false,
          };
 
          /* three */
          case FIND_DOCUMENT_BY_ENGAGEMENT_REQUEST:
            return {
              ...state,
              loading: true,
            };
          case FIND_DOCUMENT_BY_ENGAGEMENT_SUCCESS: {
            let responseJson = JSON.parse(response.data);
              return {
                ...state,
                basicDocId: responseJson[0]!== undefined?responseJson[0].basicDocId:null,
                documentPath : responseJson[0]!== undefined?responseJson[0].documentPath:null,
                loading: false,
                
            };
          }
          case FIND_DOCUMENT_BY_ENGAGEMENT_FAILURE:
            return {
              ...state,
              loading: false,
            };

        /* four */
        case DELETE_DOC_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case DELETE_DOC_SUCCESS: {
          let responseJson = JSON.parse(response.data);
            return {
              ...state,
              docDeleteResponse: responseJson[0],
              loading: false,
              
          };
        }
        case DELETE_DOC_FAILURE:
          return {
            ...state,
            loading: false,
          };
            
        default:
        return state;
    }
}