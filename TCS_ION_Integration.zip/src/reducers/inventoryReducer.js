import {
  VALIDATE_INTEREST_INVENTORY_REQUEST,
  VALIDATE_INTEREST_INVENTORY_SUCCESS,
  VALIDATE_INTEREST_INVENTORY_FAILURE,
  SAVE_INTEREST_INVENTORY_CODE_REQUEST,
  SAVE_INTEREST_INVENTORY_CODE_SUCCESS,
  SAVE_INTEREST_INVENTORY_CODE_FAILURE,
  SAVE_CONNECT_COUNSELLOR_REQUEST,
  SAVE_CONNECT_COUNSELLOR_SUCCESS,
  SAVE_CONNECT_COUNSELLOR_FAILURE,  
  VALIDATE_INVENTORY_FOR_CHATSCORE_REQUEST,
  VALIDATE_INVENTORY_FOR_CHATSCORE_SUCCESS,
  VALIDATE_INVENTORY_FOR_CHATSCORE_FAILURE,
  UPDATE_INTEREST_INVENTORY_CODE_REQUEST,
  UPDATE_INTEREST_INVENTORY_CODE_SUCCESS,
  UPDATE_INTEREST_INVENTORY_CODE_FAILURE,
  SAVE_CALL_BACK_URL_REQUEST,
  SAVE_CALL_BACK_URL_SUCCESS,
  SAVE_CALL_BACK_URL_FAILURE,

} from "../constants/actionTypes";
const initialState = {
};
export default function InventoryReducer(state = initialState, action = {}) {
    const { type, response } = action;
    switch (type) {
      /* one */
        case VALIDATE_INTEREST_INVENTORY_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case VALIDATE_INTEREST_INVENTORY_SUCCESS: {
         // console.log(typeof response);
          return {
            ...state,
            inventory: JSON.parse(response.data)[0],
            result: JSON.parse(response.data)[0]?.gameResults,
            inventorySaved: true,
            loading: false,
          };
        }
        case VALIDATE_INTEREST_INVENTORY_FAILURE:
          return {
            ...state,
            loading: false,
          };

        /* two */
        case SAVE_INTEREST_INVENTORY_CODE_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case SAVE_INTEREST_INVENTORY_CODE_SUCCESS: {
          const data = JSON.parse(response.data);
          return {
            ...state,
            inventory: data[0],
            inventorySaved: true,
            result: data[0]?.gameResults,
            loading: false,
          };
        }
        case SAVE_INTEREST_INVENTORY_CODE_FAILURE:
          return {
            ...state,
            loading: false,
          };

        /* three */
        case SAVE_CONNECT_COUNSELLOR_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case SAVE_CONNECT_COUNSELLOR_SUCCESS: {
          const data = JSON.parse(response.data);
          console.log("counseling enabled response >>", data[0]);
          return {
            ...state,
            inventory: data[0],
            counsellingEnabled: true,
            loading: false,
          };
        }
        case SAVE_CONNECT_COUNSELLOR_FAILURE:
          return {
            ...state,
            counsellingEnabled: false,
            loading: false,
          };
        /* four */
        case VALIDATE_INVENTORY_FOR_CHATSCORE_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case VALIDATE_INVENTORY_FOR_CHATSCORE_SUCCESS: {
         // console.log(typeof response);
          return {
            ...state,
            inventory: JSON.parse(response.data)[0],
            loading: false,
          };
        }
        case VALIDATE_INVENTORY_FOR_CHATSCORE_FAILURE:
          return {
            ...state,
            loading: false,
          };

          /* five */
          case UPDATE_INTEREST_INVENTORY_CODE_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case UPDATE_INTEREST_INVENTORY_CODE_SUCCESS: {
          const data = JSON.parse(response.data);
          return {
            ...state,
            inventory: data[0],
            inventorySaved: true,
            result: data[0]?.gameResults,
            loading: false,
          };
        }
        case UPDATE_INTEREST_INVENTORY_CODE_FAILURE:
          return {
            ...state,
            loading: false,
          };
        /*Data to be returned in case of call back URL*/
      case SAVE_CALL_BACK_URL_REQUEST:
        return {
          ...state,
          loading: true,
        };
      case SAVE_CALL_BACK_URL_SUCCESS: {
        const data = JSON.parse(response.data);
        return {
          ...state,
          inventory: data[0],
          inventorySaved: true,
          result: data[0]?.requestData ,
          loading: false,
        };
      }
      case SAVE_CALL_BACK_URL_FAILURE:
        return {
          ...state,
          loading: false,
        };

        default:
        return state;
    }
}