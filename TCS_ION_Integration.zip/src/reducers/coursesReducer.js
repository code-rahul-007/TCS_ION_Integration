import {
    FIND_COURSES_BY_HOLLANDCODE_REQUEST,
    FIND_COURSES_BY_HOLLANDCODE_SUCCESS,
    FIND_COURSES_BY_HOLLANDCODE_FAILURE 
  
  } from "../constants/actionTypes";
  const initialState = {
  };
  export default function coursesReducer(state = initialState, action = {}) {
      const { type, response } = action;
      switch (type) {
        
          /* one */
          case FIND_COURSES_BY_HOLLANDCODE_REQUEST:
            return {
              ...state,
              loading: true,
            };
          case FIND_COURSES_BY_HOLLANDCODE_SUCCESS: {
            let jsonObjects = JSON.parse(response.data);
              return {
                ...state,
                objectsFromHollandCode: jsonObjects,
                courses: [
                  ...new Set(jsonObjects.map((item) => item.course)),
                ],
                trades: [
                  ...new Set(jsonObjects.map((item) => item.trade)),
                ],
                courseListCompleted: true,
                loading: false,
                
            };
          }
          case FIND_COURSES_BY_HOLLANDCODE_FAILURE:
            return {
              ...state,
              loading: false,
            };
  
          default:
          return state;
      }
  }