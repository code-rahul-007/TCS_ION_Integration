import {
  GET_TOKEN_REQUEST,
  GET_TOKEN_SUCCESS,
  GET_TOKEN_FAILURE
} from "../constants/actionTypes";
const initialState = {
    token: ""
};
export default function JwtTokenReducer(state = initialState, action = {}) {
    const { type, response } = action;    switch (type) {
        case GET_TOKEN_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case GET_TOKEN_SUCCESS: {
          let jsonobjects = JSON.parse(response.data);
          return {
            ...state,
            token: jsonobjects[0].token,
            user: jsonobjects[1],
            loading: false,
          };
        }
        case GET_TOKEN_FAILURE:
          return {
            ...state,
            loading: false,
          };
        default:
        return state;
    }
}