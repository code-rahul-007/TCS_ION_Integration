import {
GET_DISTRICT_REQUEST,
GET_DISTRICT_SUCCESS,
GET_DISTRICT_FAILURE

} from "../constants/actionTypes";
const initialState = {
};
export default function cityVillageReducer(state = initialState, action = {}) {
    const { type, response } = action;
    switch (type) {
        case GET_DISTRICT_REQUEST:
          return {
            ...state,
            loading: true,
          };
        case GET_DISTRICT_SUCCESS: {
          return {
            ...state,
            cityVillageList: JSON.parse(response.data),
            loading: false,
          };
        }
        case GET_DISTRICT_FAILURE:
          return {
            ...state,
            loading: false,
          };
          
        default:
        return state;
    }
}