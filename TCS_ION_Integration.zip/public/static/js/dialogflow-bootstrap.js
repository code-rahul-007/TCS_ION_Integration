
var CUSTOM_ELEMENTS_ADAPTER_URL = 'static/js/custom-elements-es5-adapter.js';
var WEBCOMPONENTS_LOADER_URL = 'static/js/webcomponents-loader.js';
var MESSENGER_URL = 'static/js/messenger-internal.min.js';
var bot_icon = "/static/images/chatbot.png"
var bot_height = "75%";
var bot_width = "97%";
var chip_height = "70px";
var top_padding = "10%";

(function (global) {
  'use strict';



  var loadDfMessenger = function () {
    var elementScript = document.createElement('script');
    elementScript.addEventListener('load', onMessengerLoaded, false);
    elementScript.src = MESSENGER_URL;
    global.document.body.insertBefore(elementScript, null);
  };

  var onMessengerLoaded = function () {
    window.dispatchEvent(new Event('dfMessengerLoaded'))
  };

  var loadWebComponentPolyfills = function () {
    var customElementsAdapterTag = document.createElement('script');
    if (global.customElements) {
      // Import custom elements adapter which is needed for Custom element
      // classes transpiled to ES5.
      customElementsAdapterTag.src = CUSTOM_ELEMENTS_ADAPTER_URL;
      document.head.appendChild(customElementsAdapterTag);
    }
    // Import web components loader which loads polyfills based on browser
    // support.
    const webComponentsLoaderTag = document.createElement('script');
    webComponentsLoaderTag.src = WEBCOMPONENTS_LOADER_URL;
    global.document.head.appendChild(webComponentsLoaderTag);
  };

  global.addEventListener('WebComponentsReady', loadDfMessenger, false);

  var raf = global.requestAnimationFrame || global.mozRequestAnimationFrame ||
    global.webkitRequestAnimationFrame || global.msRequestAnimationFrame;
  if (raf) {
    raf(function () {
      global.setTimeout(loadWebComponentPolyfills, 0);
    });
  } else {
    global.addEventListener('load', loadWebComponentPolyfills);
  }
})(window);


window.addEventListener('dfMessengerLoaded', function (event) {
  $r1 = document.querySelector("df-messenger");
  $r2 = $r1.shadowRoot.querySelector("df-messenger-chat");
  $r4 = $r2.shadowRoot.querySelector("df-messenger-titlebar").shadowRoot.querySelector("div").querySelector("div").innerHTML = '<div style="padding-top:13px;"><div style="float: left;"><img height="80px;" width="80px;" src="/file/bot_icon.jpg" > </div><div style="float: left;line-height: 80px;">e-Counselling</div></div>'.split("/file/bot_icon.jpg").join(bot_icon)


  if (window.screen.width < 440) {
    $r4 = $r2.shadowRoot.querySelector("df-messenger-titlebar").shadowRoot.querySelector("div").querySelector("div").innerHTML = '<div style="padding-top:13px;"><div style="float: left;"><img height="50px;" width="50px;" src="/file/bot_icon.jpg" > </div><div style="float: left;line-height: 50px;font-size:25px;" >e-Counselling</div></div>'.split("/file/bot_icon.jpg").join(bot_icon)

  }


  window.addEventListener("resize", function (event) {
    console.log('window was resized');
    console.log(window.screen.width)

    if (window.screen.width < 440) {

      $r4 = $r2.shadowRoot.querySelector("df-messenger-titlebar").shadowRoot.querySelector("div").querySelector("div").innerHTML = '<div style="padding-top:13px;"><div style="float: left;"><img height="50px;" width="50px;" src="/file/bot_icon.jpg" > </div><div style="float: left;line-height: 50px;font-size:25px;">e-Counselling</div></div>'.split("/file/bot_icon.jpg").join(bot_icon)

    }

    if (window.screen.width > 440) {

      $r4 = $r2.shadowRoot.querySelector("df-messenger-titlebar").shadowRoot.querySelector("div").querySelector("div").innerHTML = '<div style="padding-top:13px;"><div style="float: left;"><img height="80px;" width="80px;" src="/file/bot_icon.jpg" > </div><div style="float: left;line-height: 80px;font-size:32px;"></div></div>'.split("/file/bot_icon.jpg").join(bot_icon)

    }
  })




});

